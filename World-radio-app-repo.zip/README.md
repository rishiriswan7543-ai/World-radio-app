# World Radio - Flutter (Android + iOS)

Reads `https://wpradio.anowhosting.com/api/app.php?action=config` for name, logo, colours,
theme list, tabs and pages, then loads stations and plays them (background + lock screen).

## 1. Create the project, then copy these files in

```bash
flutter create --org com.anowhosting --project-name worldradios worldradios
# copy this folder's pubspec.yaml and lib/ over the generated ones
cd worldradios
flutter pub get
```

Application id becomes `com.anowhosting.worldradios` (same as `billing.packageName` in your config).

## 2. Stations endpoint (IMPORTANT)

Only `action=config` was shared, so the stations call is an assumption.
Open `lib/api.dart` and edit:

- `kActionStations = 'stations'` -> your real action name
- `Station.fromJson` -> field names (it already tries id/slug, name/title,
  stream/stream_url/url, logo/image, country, language, genre/category, bitrate, tags)

If stream URLs are hidden behind another call (for example `action=stream&id=...`),
call it inside `AppState.play()` before `setAudioSource`.

## 3. Android

`android/app/src/main/kotlin/.../MainActivity.kt`

```kotlin
import com.ryanheise.audioservice.AudioServiceActivity
class MainActivity : AudioServiceActivity()
```

`android/app/src/main/AndroidManifest.xml` (inside `<manifest>`, before `<application>`):

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

On the `<application>` tag add `android:usesCleartextTraffic="true"` (many radio streams are http),
and inside `<application>`:

```xml
<service android:name="com.ryanheise.audioservice.AudioService"
    android:foregroundServiceType="mediaPlayback" android:exported="true"
    tools:ignore="Instantiatable">
  <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
</service>
<receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
    android:exported="true" tools:ignore="Instantiatable">
  <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
</receiver>
```

(add `xmlns:tools="http://schemas.android.com/tools"` to the `<manifest>` tag if missing)

Also make sure `minSdk` is 21 or higher in `android/app/build.gradle`.

## 4. iOS

`ios/Runner/Info.plist`:

```xml
<key>UIBackgroundModes</key>
<array><string>audio</string></array>
<key>NSAppTransportSecurity</key>
<dict><key>NSAllowsArbitraryLoads</key><true/></dict>
```

Build iOS on a Mac with Xcode: `flutter build ios` (platform 12.0 or higher in `ios/Podfile`).

## 5. Run

```bash
flutter run                 # debug
flutter build apk --release # Android
flutter build appbundle     # Play Store
```

## What is included (v1.1 - same design as the HTML mockup)

- 3D neumorphic cards, round glossy buttons and round country flags (dark and light), accent colour that changes the whole app
- First run: language picker (6 languages) then default-country picker
- Countries home with 3D flag coverflow, Browse (tabs from the API, grid / list / classic, search), Filters sheet
  (genre bubbles, language cards, tags, sort, view), Favourites
- Player: glow background, beat-reactive rays logo, water waves / bars / dots, LIVE badge, marquee, glass controls,
  sleep-timer dial, bass dial + presets, gold volume bar
- Equalizer: 5 bands + curve + presets (real audio effect on Android), bass boost
- Settings in grouped rows, Personalize (wave style, colours, beat colours), Privacy, VIP page
- Background playback, lock screen controls, auto reconnect

## Notes

- Release APKs are built per CPU type (`--split-per-abi`). Install `app-arm64-v8a-release.apk` on almost every modern phone.
- The visualiser is simulated (a live stream does not expose its spectrum). Beat colours animate the player screen only.
- Record and VIP purchase are placeholders (billing is disabled in your config).
- Not included yet: AdMob ads, push notifications, song titles (`nowPlaying`).
