# World Radio - Flutter (Android + iOS)

Reads `https://wpradio.anowhosting.com/api/app.php?action=config` for name, logo, colours,
theme list, tabs and pages, then loads stations and plays them (background + lock screen).

## 1. Create the project, then copy these files in

```bash
flutter create --org com.anowhosting --project-name worldradios worldradios
# copy this folder's pubspec.yaml and lib/ over the generated ones
cd worldradios
flutter pub get
```

Application id becomes `com.anowhosting.worldradios` (same as `billing.packageName` in your config).

## 2. Stations endpoint (IMPORTANT)

Only `action=config` was shared, so the stations call is an assumption.
Open `lib/api.dart` and edit:

- `kActionStations = 'stations'` -> your real action name
- `Station.fromJson` -> field names (it already tries id/slug, name/title,
  stream/stream_url/url, logo/image, country, language, genre/category, bitrate, tags)

If stream URLs are hidden behind another call (for example `action=stream&id=...`),
call it inside `AppState.play()` before `setAudioSource`.

## 3. Android

`android/app/src/main/kotlin/.../MainActivity.kt`

```kotlin
import com.ryanheise.audioservice.AudioServiceActivity
class MainActivity : AudioServiceActivity()
```

`android/app/src/main/AndroidManifest.xml` (inside `<manifest>`, before `<application>`):

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

On the `<application>` tag add `android:usesCleartextTraffic="true"` (many radio streams are http),
and inside `<application>`:

```xml
<service android:name="com.ryanheise.audioservice.AudioService"
    android:foregroundServiceType="mediaPlayback" android:exported="true"
    tools:ignore="Instantiatable">
  <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
</service>
<receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
    android:exported="true" tools:ignore="Instantiatable">
  <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
</receiver>
```

(add `xmlns:tools="http://schemas.android.com/tools"` to the `<manifest>` tag if missing)

Also make sure `minSdk` is 21 or higher in `android/app/build.gradle`.

## 4. iOS

`ios/Runner/Info.plist`:

```xml
<key>UIBackgroundModes</key>
<array><string>audio</string></array>
<key>NSAppTransportSecurity</key>
<dict><key>NSAllowsArbitraryLoads</key><true/></dict>
```

Build iOS on a Mac with Xcode: `flutter build ios` (platform 12.0 or higher in `ios/Podfile`).

## 5. Run

```bash
flutter run                 # debug
flutter build apk --release # Android
flutter build appbundle     # Play Store
```

## What is included

- Config-driven name, logo, colours, theme picker (`letUserPickColor`), default dark mode, layout, tabs, pages
- Station list or grid (equal-size cards), tabs from `tabs`, search, country and language filters
- Countries page, Favourites (stored on device), Settings (dark mode, theme colour, layout, autoplay, auto reconnect)
- Mini player and full player: logo with beat rays, water waves, LIVE badge, volume, sleep timer dial
- Background playback with lock screen / notification controls, auto reconnect (3 tries)

## Not included yet

- Ads (`ads` block, AdMob ids) -> add `google_mobile_ads`
- Billing (`billing` block, currently disabled in your config) -> add `in_app_purchase`
- Push (`push.fcmTopic`) -> add `firebase_messaging`
- Now-playing song titles (`nowPlaying`, refresh 15 s) and equalizer
- The visualiser is simulated; a live stream does not expose its spectrum to Flutter.

## GitHub Actions build (no Flutter needed on your computer)

`.github/workflows/build.yml` runs on every push to `main`:

1. Creates the `android/` and `ios/` folders when they are missing (`tool/setup_platforms.py`) and applies the
   background-audio, permission and http-stream settings from sections 3 and 4 automatically.
2. Runs `flutter analyze`, then builds a release APK and AAB (Android) and an unsigned IPA (iOS).
3. Download them from the run page: **Actions -> latest run -> Artifacts**.
4. Push a tag such as `v1.0.0` and the APK/AAB are also attached to a GitHub Release.

The APK uses the default debug signing key, so it installs on phones for testing.
For Play Store upload, add your own keystore and signing config first.
The iOS file is unsigned; signing needs an Apple developer account.
