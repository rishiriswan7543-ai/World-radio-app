#!/usr/bin/env python3
"""Creates android/ and ios/ if they are missing, then applies the settings that
background radio playback needs. Safe to run more than once."""
import glob
import os
import re
import shutil
import subprocess
import tempfile

ORG, NAME = 'com.anowhosting', 'worldradios'

if not (os.path.isdir('android') and os.path.isdir('ios')):
    tmp = tempfile.mkdtemp()
    scaffold = os.path.join(tmp, 'scaffold')
    subprocess.check_call(['flutter', 'create', '--org', ORG, '--project-name', NAME,
                           '--platforms=android,ios', scaffold])
    for d in ('android', 'ios'):
        if not os.path.isdir(d):
            shutil.copytree(os.path.join(scaffold, d), d)


def patch(path, fn):
    if not os.path.exists(path):
        return
    old = open(path, encoding='utf-8').read()
    new = fn(old)
    if new != old:
        open(path, 'w', encoding='utf-8').write(new)
        print('patched', path)


PERMS = '''    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
'''
COMPONENTS = '''        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback" android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true" tools:ignore="Instantiatable">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
'''


def manifest(s):
    if 'com.ryanheise.audioservice.AudioService' in s:
        return s
    if 'xmlns:tools' not in s:
        s = s.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)
    s = s.replace('<application', '<application android:usesCleartextTraffic="true"', 1)
    s = s.replace('<application', PERMS + '    <application', 1)
    s = s.replace('</application>', COMPONENTS + '    </application>', 1)
    return re.sub(r'android:label="[^"]*"', 'android:label="World Radio"', s, count=1)


patch('android/app/src/main/AndroidManifest.xml', manifest)


def activity(s):
    m = re.search(r'^package\s+([\w.]+)', s, re.M)
    pkg = m.group(1) if m else f'{ORG}.{NAME}'
    return (f'package {pkg}\n\nimport com.ryanheise.audioservice.AudioServiceActivity\n\n'
            'class MainActivity : AudioServiceActivity()\n')


for f in glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True):
    patch(f, activity)


def plist(s):
    if 'UIBackgroundModes' in s:
        return s
    add = ('\t<key>UIBackgroundModes</key>\n\t<array>\n\t\t<string>audio</string>\n\t</array>\n'
           '\t<key>NSAppTransportSecurity</key>\n\t<dict>\n\t\t<key>NSAllowsArbitraryLoads</key>\n\t\t<true/>\n\t</dict>\n')
    i = s.rfind('</dict>')
    s = s[:i] + add + s[i:]
    return re.sub(r'(<key>CFBundleDisplayName</key>\s*<string>)[^<]*(</string>)', r'\1World Radio\2', s, count=1)


patch('ios/Runner/Info.plist', plist)
print('platform setup done')
