// GENERATED from the HTML mockup (keys and 6 languages).
const kKeys = ['home', 'browse', 'cat', 'genre', 'lang', 'tags', 'res', 'radios', 'now', 'set', 'theme', 'wave', 'al', 'norm', 'ds', 'choose', 'sub', 'cont', 'rec', 'slp', 'eq', 'vip', 'subs', 'month', 'year', 'best', 'noads', 'hd', 'pick', 'pickS', 'dcl', 'pcol', 'beat', 'sens', 'filters', 'sortby', 'reset', 'appear', 'audio', 'notif', 'about', 'privacy', 'pers', 'pl', 'fav', 'search', 'start', 'cancel'];
const _raw = {
  'en': r"Countries|Browse|Category|Genre|Language|Tags|Results|radios|Now playing|Settings|Theme|Wave style|App language|Normalize volume|Data saver|Choose your language|You can change this anytime in Settings|Continue|Record|Sleep timer|Equalizer|Go VIP|Subscribe|Monthly|Yearly|Best value|No ads|HD sound|Choose your country|We'll open its radio stations first|Default country|App colors|Beat colors|Beat strength|Filters|Sort by|Reset|Appearance|Audio|Notifications|About|Privacy policy|Personalize|Player|Favourites|Search radios|Start timer|Stop timer",
  'ta': r"நாடுகள்|உலாவு|வகை|ஜெனர்|மொழி|டேக்குகள்|முடிவுகள்|ரேடியோக்கள்|இப்போது இயங்குகிறது|அமைப்புகள்|தீம்|அலை வடிவம்|செயலி மொழி|ஒலி சமநிலை|டேட்டா சேமிப்பு|உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்|இதை எப்போது வேண்டுமானாலும் அமைப்புகளில் மாற்றலாம்|தொடரவும்|பதிவு|தூக்க டைமர்|ஈக்வலைசர்|VIP ஆகுங்கள்|சந்தா செலுத்து|மாதம்|ஆண்டு|சிறந்த மதிப்பு|விளம்பரம் இல்லை|HD ஒலி|உங்கள் நாட்டைத் தேர்ந்தெடுக்கவும்|அந்த நாட்டு ரேடியோக்கள் முதலில் திறக்கும்|இயல்புநிலை நாடு|செயலி நிறங்கள்|பீட் நிறங்கள்|பீட் வலிமை|வடிகட்டிகள்|வரிசைப்படுத்து|மீட்டமை|தோற்றம்|ஒலி|அறிவிப்புகள்|பற்றி|தனியுரிமைக் கொள்கை|தனிப்பயனாக்கு|பிளேயர்|விருப்பங்கள்|ரேடியோவைத் தேடுங்கள்|டைமரை தொடங்கு|டைமரை நிறுத்து",
  'si': r"රටවල්|පිරික්සන්න|ප්‍රවර්ගය|ප්‍රභේදය|භාෂාව|ටැග්|ප්‍රතිඵල|රේඩියෝ|දැන් වාදනය වෙමින්|සැකසුම්|තේමාව|තරංග ශෛලිය|යෙදුමේ භාෂාව|හඬ සමතුලිත කරන්න|දත්ත සුරැකුම|ඔබේ භාෂාව තෝරන්න|ඔබට මෙය ඕනෑම වේලාවක සැකසුම් තුළ වෙනස් කළ හැක|ඉදිරියට|පටිගත කරන්න|නින්ද ටයිමරය|ඉක්වලයිසර්|VIP වන්න|දායක වන්න|මාසික|වාර්ෂික|හොඳම වටිනාකම|දැන්වීම් නැත|HD හඬ|ඔබේ රට තෝරන්න|එම රටේ රේඩියෝ මුලින්ම විවෘත වේ|පෙරනිමි රට|යෙදුමේ වර්ණ|බීට් වර්ණ|බීට් ශක්තිය|පෙරහන්|පෙළගස්වන්න|යළි පිහිටුවන්න|පෙනුම|හඬ|දැනුම්දීම්|ගැන|පෞද්ගලිකත්ව ප්‍රතිපත්තිය|පුද්ගලීකරණය|ප්ලේයර්|ප්‍රියතම|රේඩියෝ සොයන්න|ටයිමරය අරඹන්න|ටයිමරය නවතන්න",
  'hi': r"देश|खोजें|श्रेणी|शैली|भाषा|टैग|परिणाम|रेडियो|अभी चल रहा है|सेटिंग्स|थीम|तरंग शैली|ऐप की भाषा|वॉल्यूम सामान्य करें|डेटा सेवर|अपनी भाषा चुनें|आप इसे कभी भी सेटिंग्स में बदल सकते हैं|जारी रखें|रिकॉर्ड|स्लीप टाइमर|इक्वलाइज़र|VIP बनें|सदस्यता लें|मासिक|वार्षिक|सबसे बढ़िया|विज्ञापन नहीं|HD साउंड|अपना देश चुनें|उस देश के रेडियो पहले खुलेंगे|डिफ़ॉल्ट देश|ऐप के रंग|बीट रंग|बीट की ताकत|फ़िल्टर|क्रमबद्ध करें|रीसेट|रूप|ऑडियो|सूचनाएँ|जानकारी|गोपनीयता नीति|निजीकरण|प्लेयर|पसंदीदा|रेडियो खोजें|टाइमर शुरू करें|टाइमर रोकें",
  'es': r"Países|Explorar|Categoría|Género|Idioma|Etiquetas|Resultados|emisoras|Reproduciendo|Ajustes|Tema|Estilo de onda|Idioma de la app|Normalizar volumen|Ahorro de datos|Elige tu idioma|Puedes cambiarlo cuando quieras en Ajustes|Continuar|Grabar|Temporizador|Ecualizador|Hazte VIP|Suscribirse|Mensual|Anual|Mejor valor|Sin anuncios|Sonido HD|Elige tu país|Primero abriremos sus emisoras|País predeterminado|Colores de la app|Colores al ritmo|Intensidad del ritmo|Filtros|Ordenar por|Restablecer|Apariencia|Audio|Notificaciones|Acerca de|Política de privacidad|Personalizar|Reproductor|Favoritos|Buscar emisoras|Iniciar temporizador|Detener temporizador",
  'fr': r"Pays|Explorer|Catégorie|Genre|Langue|Tags|Résultats|radios|En lecture|Réglages|Thème|Style d'onde|Langue de l'app|Normaliser le volume|Économiseur de données|Choisissez votre langue|Vous pouvez le modifier à tout moment dans Réglages|Continuer|Enregistrer|Minuterie|Égaliseur|Passer VIP|S'abonner|Mensuel|Annuel|Meilleur prix|Sans pub|Son HD|Choisissez votre pays|Ses radios s'ouvriront en premier|Pays par défaut|Couleurs de l'app|Couleurs au rythme|Intensité du rythme|Filtres|Trier par|Réinitialiser|Apparence|Audio|Notifications|À propos|Politique de confidentialité|Personnaliser|Lecteur|Favoris|Rechercher une radio|Démarrer la minuterie|Arrêter la minuterie",
};
final Map<String, List<String>> _dict = {for (final e in _raw.entries) e.key: e.value.split('|')};

String tr(String lang, String key) {
  final i = kKeys.indexOf(key);
  final l = _dict[lang] ?? _dict['en']!;
  return (i >= 0 && i < l.length) ? l[i] : key;
}

// code, badge letter, native name, english name
const kLangs = [
  ['en', 'En', 'English', 'English'],
  ['ta', 'த', 'தமிழ்', 'Tamil'],
  ['si', 'සි', 'සිංහල', 'Sinhala'],
  ['hi', 'हि', 'हिन्दी', 'Hindi'],
  ['es', 'Es', 'Español', 'Spanish'],
  ['fr', 'Fr', 'Français', 'French'],
];
