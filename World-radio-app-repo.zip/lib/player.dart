import 'dart:math';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state.dart';

class Logo extends StatelessWidget {
  final String url;
  final double size;
  final bool circle;
  const Logo({super.key, required this.url, this.size = 48, this.circle = true});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ph = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: circle ? null : BorderRadius.circular(14),
        gradient: LinearGradient(colors: [cs.primary, cs.secondary]),
      ),
      child: Icon(Icons.radio, color: cs.onPrimary, size: size * .5),
    );
    if (url.isEmpty) return ph;
    final img = CachedNetworkImage(
      imageUrl: url,
      width: size,
      height: size,
      fit: BoxFit.cover,
      placeholder: (_, __) => ph,
      errorWidget: (_, __, ___) => ph,
    );
    return circle ? ClipOval(child: img) : ClipRRect(borderRadius: BorderRadius.circular(14), child: img);
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final st = s.current!;
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 6),
      child: Material(
        elevation: 4,
        color: cs.surface,
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => Navigator.push(
              context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => const PlayerPage())),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Logo(url: st.logo, size: 44),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text(s.buffering ? 'Connecting…' : 'LIVE · ${st.country}',
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                ]),
              ),
              IconButton(icon: const Icon(Icons.skip_previous), onPressed: s.prev),
              IconButton.filled(icon: Icon(s.playing ? Icons.pause : Icons.play_arrow), onPressed: s.toggle),
              IconButton(icon: const Icon(Icons.skip_next), onPressed: s.next),
            ]),
          ),
        ),
      ),
    );
  }
}

String _mmss(Duration d) =>
    '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 100))..repeat();
  double _amp = .15;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final st = s.current;
    if (st == null) return const Scaffold();
    final p = s.primary, a = s.accent, cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -.5),
            radius: 1.2,
            colors: [p.withOpacity(.35), Theme.of(context).scaffoldBackgroundColor],
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(children: [
                IconButton(icon: const Icon(Icons.keyboard_arrow_down, size: 30), onPressed: () => Navigator.pop(context)),
                const Expanded(child: Center(child: Text('Now playing'))),
                IconButton(
                  icon: Icon(s.isFav(st) ? Icons.favorite : Icons.favorite_border,
                      color: s.isFav(st) ? Colors.redAccent : null),
                  onPressed: () => s.toggleFav(st),
                ),
              ]),
            ),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: AnimatedBuilder(
                      animation: _c,
                      builder: (_, __) {
                        final t = _c.value * 100;
                        _amp += ((s.playing ? 1.0 : .15) - _amp) * .06;
                        final pulse = 1 + .08 * pow(max(0, sin(t * 12.57)), 4) * _amp;
                        return CustomPaint(
                          painter: RaysPainter(t, _amp, p, a),
                          child: Center(
                            child: FractionallySizedBox(
                              widthFactor: .43,
                              child: Transform.scale(
                                scale: pulse.toDouble(),
                                child: Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: cs.surface, width: 6),
                                    boxShadow: [BoxShadow(color: p.withOpacity(.5), blurRadius: 30)],
                                  ),
                                  child: AspectRatio(
                                    aspectRatio: 1,
                                    child: LayoutBuilder(builder: (_, bc) => Logo(url: st.logo, size: bc.maxWidth)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.redAccent.withOpacity(.5)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.circle, size: 8, color: Colors.redAccent),
                const SizedBox(width: 6),
                Text(s.buffering ? 'CONNECTING' : 'LIVE',
                    style: const TextStyle(color: Colors.redAccent, fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.w600)),
              ]),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(st.name,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            ),
            Text(
              [st.country, st.genre, if (st.bitrate > 0) '${st.bitrate} kbps'].where((e) => e.isNotEmpty).join(' · '),
              style: TextStyle(color: cs.onSurfaceVariant),
            ),
            SizedBox(
              height: 100,
              child: AnimatedBuilder(
                animation: _c,
                builder: (_, __) => CustomPaint(painter: WavesPainter(_c.value * 100, _amp, p, a), size: Size.infinite),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Column(mainAxisSize: MainAxisSize.min, children: [
                  IconButton.filledTonal(
                    icon: Icon(s.sleepLeft == null ? Icons.timer_outlined : Icons.timer),
                    onPressed: () => showSleepSheet(context),
                  ),
                  if (s.sleepLeft != null) Text(_mmss(s.sleepLeft!), style: const TextStyle(fontSize: 11)),
                ]),
                IconButton(iconSize: 38, icon: const Icon(Icons.skip_previous_rounded), onPressed: s.prev),
                GestureDetector(
                  onTap: s.toggle,
                  child: Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [p, a]),
                      boxShadow: [BoxShadow(color: p.withOpacity(.5), blurRadius: 24)],
                    ),
                    child: s.buffering
                        ? const Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
                        : Icon(s.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 44, color: Colors.white),
                  ),
                ),
                IconButton(iconSize: 38, icon: const Icon(Icons.skip_next_rounded), onPressed: s.next),
                const SizedBox(width: 48),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Row(children: [
                const Icon(Icons.volume_down),
                Expanded(
                  child: StreamBuilder<double>(
                    stream: s.player.volumeStream,
                    builder: (_, sn) => Slider(value: (sn.data ?? 1.0).clamp(0.0, 1.0).toDouble(), onChanged: s.player.setVolume),
                  ),
                ),
                const Icon(Icons.volume_up),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

void showSleepSheet(BuildContext context) {
  int m = 30;
  showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (_) => Consumer<AppState>(
      builder: (ctx, st, _) => StatefulBuilder(builder: (ctx, set) {
        final run = st.sleepLeft != null;
        final value = run ? st.sleepLeft!.inSeconds / max(1, st.sleepTotal!.inSeconds) : m / 120;
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Sleep timer', style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 16),
            SizedBox(
              width: 170,
              height: 170,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox.expand(child: CircularProgressIndicator(value: value.toDouble(), strokeWidth: 10, strokeCap: StrokeCap.round)),
                Text(run ? _mmss(st.sleepLeft!) : '$m min', style: Theme.of(ctx).textTheme.headlineMedium),
              ]),
            ),
            if (!run) ...[
              Slider(value: m.toDouble(), min: 5, max: 120, divisions: 23, onChanged: (v) => set(() => m = v.round())),
              Wrap(spacing: 8, children: [
                for (final x in [10, 15, 30, 45, 60, 90]) ActionChip(label: Text('$x'), onPressed: () => set(() => m = x)),
              ]),
            ],
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () {
                st.setSleep(run ? null : Duration(minutes: m));
                if (!run) Navigator.pop(ctx);
              },
              child: Text(run ? 'Stop timer' : 'Start timer'),
            ),
          ]),
        );
      }),
    ),
  );
}

// Simulated visualiser (a live stream does not expose its spectrum to Flutter).
class RaysPainter extends CustomPainter {
  final double t, amp;
  final Color a, b;
  RaysPainter(this.t, this.amp, this.a, this.b);

  @override
  void paint(Canvas c, Size sz) {
    final cx = sz.width / 2, cy = sz.height / 2, r0 = sz.width * .285, ext = sz.width * .15;
    final paint = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = sz.width * .015
      ..shader = LinearGradient(colors: [a, b]).createShader(Offset.zero & sz)
      ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 3);
    final beat = pow(max(0, sin(t * 12.57)), 4).toDouble();
    for (var i = 0; i < 72; i++) {
      final an = i / 72 * 2 * pi;
      final v = ((sin(t * 3 + i * .7) * .5 + .5) * (sin(t * 2 + i * .3) * .5 + .5) * amp + beat * .3 * amp)
          .clamp(0.0, 1.0)
          .toDouble();
      final r1 = r0 + sz.width * .02 + v * ext;
      c.drawLine(Offset(cx + cos(an) * r0, cy + sin(an) * r0), Offset(cx + cos(an) * r1, cy + sin(an) * r1), paint);
    }
    for (var k = 0; k < 3; k++) {
      final ph = (t * .9 + k / 3) % 1;
      c.drawCircle(
        Offset(cx, cy),
        r0 + ph * sz.width * .19,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = a.withOpacity((1 - ph) * .3 * amp),
      );
    }
  }

  @override
  bool shouldRepaint(RaysPainter o) => true;
}

class WavesPainter extends CustomPainter {
  final double t, amp;
  final Color a, b;
  WavesPainter(this.t, this.amp, this.a, this.b);

  @override
  void paint(Canvas c, Size sz) {
    final w = sz.width, h = sz.height, base = h * .58;
    double fy(double x, int k) =>
        base + sin(x * .018 + t * (1.2 + k * .5) + k * 2) * h * .2 * amp * (1 - k * .18) + sin(x * .045 - t * 1.7 + k) * h * .07 * amp;
    for (var k = 2; k >= 0; k--) {
      final fill = Path()..moveTo(0, h);
      final line = Path();
      for (double x = 0; x <= w; x += 4) {
        fill.lineTo(x, fy(x, k));
        x == 0 ? line.moveTo(x, fy(x, k)) : line.lineTo(x, fy(x, k));
      }
      fill.lineTo(w, h);
      fill.close();
      c.drawPath(
        fill,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [a.withOpacity(k == 0 ? .4 : .28), a.withOpacity(0)],
          ).createShader(Rect.fromLTWH(0, base - h * .3, w, h)),
      );
      c.drawPath(
        line,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = k == 0 ? 3 : 2
          ..color = (k == 0 ? b : a).withOpacity(k == 0 ? 1 : .5),
      );
    }
  }

  @override
  bool shouldRepaint(WavesPainter o) => true;
}
