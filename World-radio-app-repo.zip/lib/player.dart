import 'dart:math';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'api.dart';
import 'design.dart';
import 'more.dart';
import 'state.dart';

class _Amp {
  double v = .15;
}

List<Color> _cols(Color ac, Color a2, bool beatOn, double t, double bt) {
  if (!beatOn) return [ac, a2];
  final h = (t * 30 + bt * 40) % 360;
  return [
    HSLColor.fromAHSL(1, h, .85, (.6 + bt * .06).clamp(0.0, 1.0).toDouble()).toColor(),
    HSLColor.fromAHSL(1, (h + 55) % 360, .8, .56).toColor(),
  ];
}

double _beat(double t, double amp, double strength) => pow(max(0, sin(t * 12.57)), 4).toDouble() * strength * min(amp, 1.2);

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 1000))..repeat();
  final _amp = _Amp();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final a = context.app;
    final st = context.select<AppState, Station?>((s) => s.current);
    final playing = context.select<AppState, bool>((s) => s.playing);
    final buffering = context.select<AppState, bool>((s) => s.buffering);
    final wave = context.select<AppState, String>((s) => s.wave);
    final beatOn = context.select<AppState, bool>((s) => s.beatOn);
    final strength = context.select<AppState, double>((s) => s.beat);
    final fav = context.select<AppState, bool>((s) => st != null && s.isFav(st));
    final top = MediaQuery.of(context).padding.top;

    if (st == null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.headphones, size: 48, color: d.ac),
          const SizedBox(height: 8),
          Text('Pick a station to start', style: ts(d, m: true)),
        ]),
      );
    }

    Widget live(Widget Function(List<Color> c, double t, double bt) b) => beatOn
        ? AnimatedBuilder(
            animation: _c,
            builder: (_, __) {
              final t = _c.value * 1000;
              final bt = _beat(t, _amp.v, strength);
              return b(_cols(d.ac, d.a2, true, t, bt), t, bt);
            })
        : b([d.ac, d.a2], 0, 0);

    return Stack(fit: StackFit.expand, children: [
      Positioned.fill(
        child: live((c, t, bt) => DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(center: const Alignment(0, -.6), radius: 1.1, colors: [c[0].withOpacity(.32), Colors.transparent]),
              ),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(center: const Alignment(0, 1.2), radius: .9, colors: [c[1].withOpacity(.22), Colors.transparent]),
                ),
              ),
            )),
      ),
      Column(children: [
        SizedBox(height: top + 6),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            const SizedBox(width: 70),
            Expanded(child: Center(child: Text(context.t('now'), style: ts(d, s: 12, m: true)))),
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipPage())),
              child: Container(
                width: 70,
                padding: const EdgeInsets.symmetric(vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.07), borderRadius: BorderRadius.circular(99), border: Border.all(color: Colors.white.withOpacity(.12))),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.fiber_manual_record, size: 12, color: _redC),
                  const SizedBox(width: 4),
                  Text(context.t('rec'), style: ts(d, s: 11, b: true)),
                ]),
              ),
            ),
          ]),
        ),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: AspectRatio(
                aspectRatio: 1,
                child: Stack(alignment: Alignment.center, children: [
                  Positioned.fill(
                    child: RepaintBoundary(
                      child: CustomPaint(painter: _Rays(_c, _amp, playing, beatOn, strength, d.ac, d.a2, wave)),
                    ),
                  ),
                  FractionallySizedBox(
                    widthFactor: .43,
                    child: AnimatedBuilder(
                      animation: _c,
                      builder: (_, child) {
                        final bt = _beat(_c.value * 1000, _amp.v, strength);
                        return Transform.scale(scale: 1 + .08 * bt, child: child);
                      },
                      child: live((c, t, bt) => _PlayerLogo(st, c)),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: _redC.withOpacity(.14),
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: _redC.withOpacity(.5)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.circle, size: 8, color: _redC),
            const SizedBox(width: 7),
            Text(buffering ? 'CONNECTING' : 'LIVE', style: const TextStyle(color: Color(0xFFFF6B86), fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.w600)),
          ]),
        ),
        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Text(st.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(d, s: 20, b: true)),
        ),
        const SizedBox(height: 4),
        SizedBox(
          height: 20,
          child: _Marquee(
            [st.country, st.genre, st.language, if (st.bitrate > 0) '${st.bitrate} kbps'].where((e) => e.isNotEmpty).join(' · '),
            ts(d, s: 12, m: true),
            _c,
          ),
        ),
        SizedBox(
          height: 110,
          child: RepaintBoundary(child: CustomPaint(size: Size.infinite, painter: _Waves(_c, _amp, beatOn, strength, d.ac, d.a2, wave))),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
          child: LayoutBuilder(builder: (_, bc) {
            final g = (bc.maxWidth * .16).clamp(40.0, 54.0).toDouble();
            return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _Glass(Icons.equalizer, g, () => showSound(context)),
              _Glass(Icons.skip_previous, g * .8, a.prev),
              live((c, t, bt) => Gloss(
                    size: g * 1.5,
                    glow: 26,
                    grad: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: c),
                    onTap: a.toggle,
                    child: buffering
                        ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
                        : Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: g * .8),
                  )),
              _Glass(Icons.skip_next, g * .8, a.next),
              ValueListenableBuilder<Duration?>(
                valueListenable: a.sleepLeft,
                builder: (_, left, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                  _Glass(Icons.timer_outlined, g, () => showSleep(context), on: left != null),
                  const SizedBox(height: 3),
                  Text(left == null ? context.t('slp') : _mmss(left), style: ts(d, s: 9, m: true)),
                ]),
              ),
            ]);
          }),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
          child: Row(children: [
            Icon(Icons.volume_down, color: d.mu, size: 20),
            Expanded(
              child: StreamBuilder<double>(
                stream: a.player.volumeStream,
                builder: (_, sn) => SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 8,
                    activeTrackColor: d.ac,
                    inactiveTrackColor: Colors.white.withOpacity(.16),
                    thumbShape: _BarThumb(),
                    overlayShape: SliderComponentShape.noOverlay,
                    trackShape: const RoundedRectSliderTrackShape(),
                  ),
                  child: Slider(value: (sn.data ?? 1.0).clamp(0.0, 1.0).toDouble(), onChanged: a.player.setVolume),
                ),
              ),
            ),
            Icon(Icons.volume_up, color: d.mu, size: 20),
          ]),
        ),
      ]),
    ]);
  }
}

const _redC = Color(0xFFFF4D6D);

String _mmss(Duration d) => '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

class _BarThumb extends SliderComponentShape {
  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) => const Size(4, 30);

  @override
  void paint(PaintingContext context, Offset center,
      {required Animation<double> activationAnimation,
      required Animation<double> enableAnimation,
      required bool isDiscrete,
      required TextPainter labelPainter,
      required RenderBox parentBox,
      required SliderThemeData sliderTheme,
      required TextDirection textDirection,
      required double value,
      required double textScaleFactor,
      required Size sizeWithOverflow}) {
    context.canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: center, width: 4, height: 30), const Radius.circular(2)), Paint()..color = Colors.white);
  }
}

class _Glass extends StatelessWidget {
  final IconData icon;
  final double size;
  final VoidCallback onTap;
  final bool on;
  const _Glass(this.icon, this.size, this.onTap, {this.on = false});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: on ? d.ac : Colors.white.withOpacity(.07),
          border: Border.all(color: Colors.white.withOpacity(.12)),
        ),
        child: Icon(icon, size: size * .42, color: on ? Colors.white : d.tx),
      ),
    );
  }
}

class _PlayerLogo extends StatelessWidget {
  final Station st;
  final List<Color> cols;
  const _PlayerLogo(this.st, this.cols);

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: d.cd, width: 6),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: cols),
          boxShadow: [BoxShadow(color: cols[0].withOpacity(.45), blurRadius: 30)],
        ),
        child: ClipOval(
          child: Stack(fit: StackFit.expand, children: [
            const Center(child: Icon(Icons.radio, color: Colors.white, size: 44)),
            if (st.logo.isNotEmpty)
              CachedNetworkImage(
                imageUrl: st.logo,
                fit: BoxFit.cover,
                memCacheWidth: 400,
                placeholder: (_, __) => const SizedBox.shrink(),
                errorWidget: (_, __, ___) => const SizedBox.shrink(),
              ),
            IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(center: const Alignment(-.4, -.56), radius: .9, colors: [Colors.white.withOpacity(.32), Colors.transparent], stops: const [0, .55]),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Marquee extends StatelessWidget {
  final String text;
  final TextStyle style;
  final Animation<double> anim;
  const _Marquee(this.text, this.style, this.anim);

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, bc) {
        final tp = TextPainter(text: TextSpan(text: text, style: style), textDirection: TextDirection.ltr, maxLines: 1)..layout();
        final w = bc.maxWidth, tw = tp.width;
        if (tw <= w) return Center(child: Text(text, style: style));
        return ClipRect(
          child: AnimatedBuilder(
            animation: anim,
            builder: (_, __) {
              final x = w - ((anim.value * 1000 * 40) % (w + tw));
              return OverflowBox(
                alignment: Alignment.centerLeft,
                maxWidth: double.infinity,
                child: Transform.translate(offset: Offset(x, 0), child: Text(text, style: style, softWrap: false)),
              );
            },
          ),
        );
      });
}

// ------------------------------------------------------------ painters (repaint only, no widget rebuilds)
class _Rays extends CustomPainter {
  final AnimationController c;
  final _Amp amp;
  final bool playing, beatOn;
  final double strength;
  final Color ac, a2;
  final String wave;
  _Rays(this.c, this.amp, this.playing, this.beatOn, this.strength, this.ac, this.a2, this.wave) : super(repaint: c);

  @override
  void paint(Canvas cv, Size sz) {
    final t = c.value * 1000;
    amp.v += ((playing ? 1.0 : .15) - amp.v) * .06;
    final bt = _beat(t, amp.v, strength);
    final k = _cols(ac, a2, beatOn, t, bt);
    final cx = sz.width / 2, cy = sz.height / 2, r0 = sz.width * .285, ext = sz.width * .15;
    for (var i = 0; i < 3; i++) {
      final ph = (t * .9 + i / 3) % 1;
      cv.drawCircle(Offset(cx, cy), r0 + ph * sz.width * .19,
          Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = k[0].withOpacity(((1 - ph) * .3 * amp.v).clamp(0.0, 1.0).toDouble()));
    }
    final path = Path();
    if (wave == 'wave') {
      for (var i = 0; i <= 120; i++) {
        final an = i / 120 * 2 * pi;
        final r = r0 + sz.width * .04 + sin(an * 6 + t * 3) * sz.width * .023 * amp.v + sin(an * 11 - t * 4) * sz.width * .012 * amp.v + bt * sz.width * .03;
        final p = Offset(cx + cos(an) * r, cy + sin(an) * r);
        i == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
      }
      path.close();
    } else {
      for (var i = 0; i < 72; i++) {
        final an = i / 72 * 2 * pi;
        final v = ((sin(t * 3 + i * .7) * .5 + .5) * (sin(t * 2 + i * .3) * .5 + .5) * amp.v + bt * .3).clamp(0.0, 1.0).toDouble();
        final r1 = r0 + sz.width * .02 + v * ext;
        path.moveTo(cx + cos(an) * r0, cy + sin(an) * r0);
        path.lineTo(cx + cos(an) * r1, cy + sin(an) * r1);
      }
    }
    final shader = LinearGradient(begin: Alignment.bottomLeft, end: Alignment.topRight, colors: k).createShader(Offset.zero & sz);
    cv.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = sz.width * .04..shader = shader..color = k[0].withOpacity(.22));
    cv.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = sz.width * .014..shader = shader);
  }

  @override
  bool shouldRepaint(_Rays o) => o.playing != playing || o.beatOn != beatOn || o.ac != ac || o.wave != wave;
}

class _Waves extends CustomPainter {
  final AnimationController c;
  final _Amp amp;
  final bool beatOn;
  final double strength;
  final Color ac, a2;
  final String wave;
  _Waves(this.c, this.amp, this.beatOn, this.strength, this.ac, this.a2, this.wave) : super(repaint: c);

  @override
  void paint(Canvas cv, Size sz) {
    final t = c.value * 1000, w = sz.width, h = sz.height;
    final a = min(amp.v * strength, 1.15);
    final k = _cols(ac, a2, beatOn, t, _beat(t, amp.v, strength));
    if (wave == 'wave') {
      final base = h * .58;
      double fy(double x, int n) =>
          base + sin(x * .018 + t * (1.2 + n * .5) + n * 2) * h * .2 * a * (1 - n * .18) + sin(x * .045 - t * 1.7 + n) * h * .07 * a;
      for (var n = 2; n >= 0; n--) {
        final fill = Path()..moveTo(0, h);
        final line = Path();
        for (double x = 0; x <= w; x += 6) {
          fill.lineTo(x, fy(x, n));
          x == 0 ? line.moveTo(x, fy(x, n)) : line.lineTo(x, fy(x, n));
        }
        fill.lineTo(w, h);
        fill.close();
        cv.drawPath(
          fill,
          Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [k[0].withOpacity(n == 0 ? .4 : .28), k[0].withOpacity(0)]).createShader(Rect.fromLTWH(0, base - h * .3, w, h)),
        );
        cv.drawPath(line, Paint()..style = PaintingStyle.stroke..strokeWidth = n == 0 ? 3 : 2..color = (n == 0 ? k[1] : k[0]).withOpacity(n == 0 ? 1 : .5));
      }
    } else if (wave == 'bars') {
      final n = max(12, (w / 10).round()), bw = w / n, m = h * .62;
      final p = Paint()..strokeCap = StrokeCap.round..strokeWidth = max(3.0, bw * .6)..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [k[1], k[0]]).createShader(Rect.fromLTWH(0, 0, w, m));
      final up = Path(), down = Path();
      for (var i = 0; i < n; i++) {
        final v = ((sin(t * 3 + i * .5) * .5 + .5) * (sin(t * 1.7 + i * 1.3) * .5 + .5) * a * 1.3).clamp(0.0, 1.0).toDouble();
        final len = 4 + v * (m - 10), x = i * bw + bw / 2;
        up..moveTo(x, m)..lineTo(x, m - len);
        down..moveTo(x, m + 4)..lineTo(x, m + 4 + len * .5);
      }
      cv.drawPath(up, p..style = PaintingStyle.stroke);
      cv.drawPath(down, Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = p.strokeWidth..color = k[0].withOpacity(.28));
    } else {
      final n = max(8, (w / 16).round()), rows = max(4, (h / 13).floor()), dw = w / n, rh = h / rows;
      final on = Paint()..color = k[0], on2 = Paint()..color = k[1], off = Paint()..color = k[0].withOpacity(.12);
      for (var i = 0; i < n; i++) {
        final v = ((sin(t * 3 + i * .6) * .5 + .5) * (sin(t * 1.9 + i * 1.1) * .5 + .5) * a * 1.3).clamp(0.0, 1.0).toDouble();
        for (var r = 0; r < rows; r++) {
          final lit = r < v * rows;
          cv.drawCircle(Offset(i * dw + dw / 2, h - (r + .5) * rh), min(dw, rh) * .32, lit ? (r < v * rows * .5 ? on : on2) : off);
        }
      }
    }
  }

  @override
  bool shouldRepaint(_Waves o) => o.beatOn != beatOn || o.ac != ac || o.wave != wave;
}

class _Arc extends CustomPainter {
  final double v;
  final Color ac, track;
  final bool dial270;
  _Arc(this.v, this.ac, this.track, this.dial270);

  @override
  void paint(Canvas cv, Size sz) {
    final r = Rect.fromLTWH(7, 7, sz.width - 14, sz.height - 14);
    final start = dial270 ? 3 * pi / 4 : -pi / 2, total = dial270 ? 1.5 * pi : 2 * pi;
    final p = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 11;
    cv.drawArc(r, start, total, false, p..color = track);
    cv.drawArc(r, start, total * v.clamp(0.0, 1.0), false, p..color = ac);
  }

  @override
  bool shouldRepaint(_Arc o) => o.v != v || o.ac != ac;
}

// ------------------------------------------------------------ sleep timer sheet (dial)
void showSleep(BuildContext context) => showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _SleepSheet(),
    );

Widget _sheet(Ds d, List<Widget> children) => Container(
      decoration: BoxDecoration(color: d.cd, borderRadius: const BorderRadius.vertical(top: Radius.circular(26)), boxShadow: [BoxShadow(color: d.sh, blurRadius: 30)]),
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 22),
      child: SafeArea(top: false, child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 40, height: 4, decoration: BoxDecoration(color: d.mu.withOpacity(.5), borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 12),
        ...children,
      ])),
    );

class _SleepSheet extends StatefulWidget {
  const _SleepSheet();
  @override
  State<_SleepSheet> createState() => _SleepSheetState();
}

class _SleepSheetState extends State<_SleepSheet> {
  int m = 30;

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final a = context.app;
    return ValueListenableBuilder<Duration?>(
      valueListenable: a.sleepLeft,
      builder: (_, left, __) {
        final run = left != null;
        final v = run ? left!.inSeconds / max(1, a.sleepTotal!.inSeconds) : m / 120;
        return _sheet(d, [
          Row(children: [
            Expanded(child: Text(context.t('slp'), style: ts(d, s: 16, b: true))),
            GestureDetector(onTap: () => Navigator.pop(context), child: Well(Icons.close, size: 30)),
          ]),
          const SizedBox(height: 10),
          SizedBox(
            width: 170,
            height: 170,
            child: Stack(alignment: Alignment.center, children: [
              Positioned.fill(child: CustomPaint(painter: _Arc(v, d.ac, d.bg, false))),
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text(run ? _mmss(left!) : '$m', style: ts(d, s: 34, b: true)),
                Text('min', style: ts(d, s: 11, m: true)),
              ]),
            ]),
          ),
          if (!run) ...[
            SliderTheme(
              data: SliderThemeData(trackHeight: 8, activeTrackColor: d.ac, inactiveTrackColor: d.bg, thumbColor: Colors.white, overlayShape: SliderComponentShape.noOverlay),
              child: Slider(value: m.toDouble(), min: 5, max: 120, divisions: 23, onChanged: (x) => setState(() => m = x.round())),
            ),
            Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
              for (final x in const [10, 15, 30, 45, 60, 90]) Pill('$x', on: m == x, onTap: () => setState(() => m = x)),
            ]),
          ],
          const SizedBox(height: 16),
          Cta(run ? context.t('cancel') : context.t('start'), onTap: () {
            a.setSleep(run ? null : Duration(minutes: m));
            if (!run) Navigator.pop(context);
          }),
        ]);
      },
    );
  }
}

// ------------------------------------------------------------ sound sheet (bass dial + presets)
void showSound(BuildContext context) => showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _SoundSheet(),
    );

class _SoundSheet extends StatelessWidget {
  const _SoundSheet();

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    final v = (a.bands[0] + 12) / 24;
    void drag(Offset p) {
      var ang = atan2(p.dy - 85, p.dx - 85) - 3 * pi / 4;
      while (ang < 0) {
        ang += 2 * pi;
      }
      final x = ang > 1.5 * pi ? (ang < 1.75 * pi ? 1.0 : 0.0) : ang / (1.5 * pi);
      a.setBand(0, (x * 24 - 12).round());
    }

    return _sheet(d, [
      Row(children: [
        Expanded(child: Text(a.t('eq'), style: ts(d, s: 16, b: true))),
        Tog(a.eqOn, a.setEqOn),
        const SizedBox(width: 12),
        GestureDetector(onTap: () => Navigator.pop(context), child: const Well(Icons.close, size: 30)),
      ]),
      const SizedBox(height: 10),
      GestureDetector(
        onPanStart: (e) => drag(e.localPosition),
        onPanUpdate: (e) => drag(e.localPosition),
        onTapDown: (e) => drag(e.localPosition),
        child: SizedBox(
          width: 170,
          height: 170,
          child: Stack(alignment: Alignment.center, children: [
            Positioned.fill(child: CustomPaint(painter: _Arc(v, d.ac, d.bg, true))),
            Column(mainAxisSize: MainAxisSize.min, children: [
              Text('${(v * 100).round()}', style: ts(d, s: 34, b: true)),
              Text('Bass', style: ts(d, s: 11, m: true)),
            ]),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      SizedBox(
        height: 36,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final p in kPresets.keys)
            Padding(padding: const EdgeInsets.only(right: 8), child: Pill(p, on: a.preset == p, onTap: () => a.setPreset(p))),
        ]),
      ),
      const SizedBox(height: 14),
      Cta('Equalizer', onTap: () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const EqPage()));
      }),
    ]);
  }
}

/// Small animated preview used on the Personalize screen.
class WavePreview extends StatefulWidget {
  const WavePreview({super.key});
  @override
  State<WavePreview> createState() => _WavePreviewState();
}

class _WavePreviewState extends State<WavePreview> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 1000))..repeat();
  final _amp = _Amp()..v = 1.0;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final wave = context.select<AppState, String>((s) => s.wave);
    return SizedBox(height: 90, child: RepaintBoundary(child: CustomPaint(size: Size.infinite, painter: _Waves(_c, _amp, false, 1, d.ac, d.a2, wave))));
  }
}
