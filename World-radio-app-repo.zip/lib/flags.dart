const _names =
    'afghanistan|af,albania|al,algeria|dz,argentina|ar,armenia|am,australia|au,austria|at,azerbaijan|az,bahrain|bh,bangladesh|bd,belarus|by,belgium|be,bolivia|bo,bosnia and herzegovina|ba,brazil|br,bulgaria|bg,cambodia|kh,cameroon|cm,canada|ca,chile|cl,china|cn,colombia|co,costa rica|cr,croatia|hr,cuba|cu,cyprus|cy,czech republic|cz,czechia|cz,denmark|dk,dominican republic|do,ecuador|ec,egypt|eg,el salvador|sv,estonia|ee,ethiopia|et,finland|fi,france|fr,georgia|ge,germany|de,ghana|gh,greece|gr,guatemala|gt,haiti|ht,honduras|hn,hong kong|hk,hungary|hu,iceland|is,india|in,indonesia|id,iran|ir,iraq|iq,ireland|ie,israel|il,italy|it,jamaica|jm,japan|jp,jordan|jo,kazakhstan|kz,kenya|ke,korea|kr,south korea|kr,north korea|kp,kuwait|kw,latvia|lv,lebanon|lb,libya|ly,lithuania|lt,luxembourg|lu,malaysia|my,maldives|mv,malta|mt,mauritius|mu,mexico|mx,moldova|md,mongolia|mn,morocco|ma,myanmar|mm,nepal|np,netherlands|nl,new zealand|nz,nicaragua|ni,nigeria|ng,norway|no,oman|om,pakistan|pk,palestine|ps,panama|pa,paraguay|py,peru|pe,philippines|ph,poland|pl,portugal|pt,puerto rico|pr,qatar|qa,romania|ro,russia|ru,russian federation|ru,saudi arabia|sa,senegal|sn,serbia|rs,singapore|sg,slovakia|sk,slovenia|si,somalia|so,south africa|za,spain|es,sri lanka|lk,sudan|sd,sweden|se,switzerland|ch,syria|sy,taiwan|tw,tanzania|tz,thailand|th,tunisia|tn,turkey|tr,türkiye|tr,uganda|ug,ukraine|ua,united arab emirates|ae,uae|ae,united kingdom|gb,uk|gb,england|gb,united states|us,usa|us,united states of america|us,uruguay|uy,uzbekistan|uz,venezuela|ve,vietnam|vn,yemen|ye,zambia|zm,zimbabwe|zw';

final Map<String, String> _iso = {
  for (final p in _names.split(',')) p.split('|')[0]: p.split('|')[1],
};

/// ISO-2 code (lower case) for a country name or code, or null when unknown.
String? isoOf(String name) {
  final n = name.trim().toLowerCase();
  if (_iso.containsKey(n)) return _iso[n];
  if (RegExp(r'^[a-z]{2}$').hasMatch(n)) return n;
  return null;
}
