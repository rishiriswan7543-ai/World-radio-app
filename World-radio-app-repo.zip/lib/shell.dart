import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'api.dart';
import 'browse.dart';
import 'design.dart';
import 'i18n.dart';
import 'more.dart';
import 'player.dart';
import 'state.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final loading = context.select<AppState, bool>((s) => s.loading);
    final hasCfg = context.select<AppState, bool>((s) => s.cfg != null);
    final onb = context.select<AppState, bool>((s) => s.onboarded);
    final name = context.select<AppState, String>((s) => s.cfg?.name ?? 'World Radio');
    final base = ThemeData(brightness: d.dark ? Brightness.dark : Brightness.light, useMaterial3: true);
    final tt = GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(bodyColor: d.tx, displayColor: d.tx);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: name,
      theme: base.copyWith(
        scaffoldBackgroundColor: d.bg,
        textTheme: tt,
        colorScheme: ColorScheme.fromSeed(seedColor: d.ac, brightness: base.brightness)
            .copyWith(primary: d.ac, secondary: d.a2, surface: d.cd),
      ),
      home: loading ? const _Splash() : (!hasCfg ? const _Failed() : (!onb ? const Onboard() : const Shell())),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Gloss(size: 84, glow: 30, child: const Icon(Icons.radio, color: Colors.white, size: 40)),
          const SizedBox(height: 16),
          Text('World Radio', style: ts(d, s: 22, b: true)),
          const SizedBox(height: 24),
          SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3, color: d.ac)),
        ]),
      ),
    );
  }
}

class _Failed extends StatelessWidget {
  const _Failed();
  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.wifi_off, size: 56, color: d.ac),
            const SizedBox(height: 12),
            Text('Could not reach the server', style: ts(d, s: 15, b: true)),
            const SizedBox(height: 6),
            Text(context.app.error ?? '', textAlign: TextAlign.center, style: ts(d, s: 11, m: true)),
            const SizedBox(height: 20),
            Cta('Retry', onTap: () => context.app.reload()),
          ]),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------ onboarding
class Onboard extends StatefulWidget {
  const Onboard({super.key});
  @override
  State<Onboard> createState() => _OnboardState();
}

class _OnboardState extends State<Onboard> {
  int step = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: step == 0
              ? LangBody(onDone: () => setState(() => step = 1))
              : CountryBody(onDone: () => context.app.finishOnboarding()),
        ),
      );
}

class LangPage extends StatelessWidget {
  const LangPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: LangBody(onDone: () => Navigator.pop(context))));
}

class CountryPage extends StatelessWidget {
  const CountryPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: CountryBody(onDone: () => Navigator.pop(context))));
}

class _Brand extends StatelessWidget {
  const _Brand();
  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final name = context.select<AppState, String>((s) => s.cfg?.name ?? 'World Radio');
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Gloss(size: 34, child: const Icon(Icons.radio, color: Colors.white, size: 17)),
      const SizedBox(width: 10),
      Text(name, style: ts(d, s: 16, b: true)),
    ]);
  }
}

class LangBody extends StatelessWidget {
  final VoidCallback onDone;
  const LangBody({super.key, required this.onDone});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final cur = context.select<AppState, String>((s) => s.lang);
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      child: Column(children: [
        const _Brand(),
        const SizedBox(height: 22),
        Text(context.t('choose'), textAlign: TextAlign.center, style: ts(d, s: 20, b: true)),
        const SizedBox(height: 4),
        Text(context.t('sub'), textAlign: TextAlign.center, style: ts(d, s: 11, m: true)),
        const SizedBox(height: 14),
        Expanded(
          child: ListView(children: [
            for (final l in kLangs)
              Padding(
                padding: const EdgeInsets.only(bottom: 10, left: 4, right: 4),
                child: Neo(
                  sel: cur == l[0],
                  pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  onTap: () => context.app.setLang(l[0]),
                  child: Row(children: [
                    cur == l[0]
                        ? Gloss(size: 36, child: Text(l[1], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)))
                        : Container(
                            width: 36,
                            height: 36,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: d.bg),
                            child: Text(l[1], style: ts(d, s: 14, b: true, m: true))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(l[2], style: ts(d, s: 15, b: true)),
                        Text(l[3], style: ts(d, s: 11, m: true)),
                      ]),
                    ),
                    Icon(Icons.check_circle_outline, color: cur == l[0] ? d.ac : Colors.transparent),
                  ]),
                ),
              ),
          ]),
        ),
        const SizedBox(height: 10),
        Cta(context.t('cont'), onTap: onDone),
      ]),
    );
  }
}

class CountryBody extends StatelessWidget {
  final VoidCallback onDone;
  const CountryBody({super.key, required this.onDone});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final list = context.select<AppState, List<MapEntry<String, int>>>((s) => s.countries);
    final sel = context.select<AppState, String>((s) => s.homeCountry);
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      child: Column(children: [
        const _Brand(),
        const SizedBox(height: 22),
        Text(context.t('pick'), textAlign: TextAlign.center, style: ts(d, s: 20, b: true)),
        const SizedBox(height: 4),
        Text(context.t('pickS'), textAlign: TextAlign.center, style: ts(d, s: 11, m: true)),
        const SizedBox(height: 14),
        Expanded(
          child: GridView.builder(
            itemCount: list.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4, mainAxisSpacing: 14, crossAxisSpacing: 6, childAspectRatio: .78),
            itemBuilder: (_, i) {
              final c = list[i].key;
              final on = c == sel;
              return GestureDetector(
                onTap: () => context.app.setDefCountry(c),
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: on ? d.ac : Colors.transparent, width: 2)),
                    child: FlagC(c, size: 52),
                  ),
                  const SizedBox(height: 6),
                  Text(c, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 11, b: on, m: !on)),
                ]),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Cta(context.t('cont'), onTap: onDone),
      ]),
    );
  }
}

// ------------------------------------------------------------ shell
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final _seen = <int>{0};

  @override
  Widget build(BuildContext context) {
    final nav = context.select<AppState, int>((s) => s.nav);
    final mini = context.select<AppState, bool>((s) => s.current != null);
    _seen.add(nav);
    const pages = <Widget>[HomePage(), BrowsePage(), FavsPage(), PlayerPage(), SettingsPage()];
    return Scaffold(
      body: SafeArea(
        top: nav != 3,
        child: Column(children: [
          Expanded(
            child: IndexedStack(index: nav, children: [for (var i = 0; i < pages.length; i++) _seen.contains(i) ? pages[i] : const SizedBox()]),
          ),
          if (mini && nav != 3) const MiniPlayer(),
          const PillNav(),
        ]),
      ),
    );
  }
}

class PillNav extends StatelessWidget {
  const PillNav({super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final nav = context.select<AppState, int>((s) => s.nav);
    const items = [
      [Icons.public, 'home'],
      [Icons.grid_view_rounded, 'browse'],
      [Icons.favorite_border, 'fav'],
      [Icons.headphones, 'pl'],
      [Icons.tune, 'set'],
    ];
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 6, 14, 10),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: d.cd,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: d.dark ? d.hi : d.ac.withOpacity(.28)),
        boxShadow: [BoxShadow(color: d.sh, offset: const Offset(0, 6), blurRadius: 16)],
      ),
      child: Row(children: [
        for (var i = 0; i < items.length; i++)
          Expanded(
            child: GestureDetector(
              onTap: () => context.app.setNav(i),
              behavior: HitTestBehavior.opaque,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 7),
                decoration: BoxDecoration(gradient: nav == i ? d.grad : null, borderRadius: BorderRadius.circular(20)),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(items[i][0] as IconData, size: 19, color: nav == i ? Colors.white : d.mu),
                  Text(context.t(items[i][1] as String),
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 9, b: true, c: nav == i ? Colors.white : d.mu)),
                ]),
              ),
            ),
          ),
      ]),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final st = context.select<AppState, Station?>((s) => s.current);
    final playing = context.select<AppState, bool>((s) => s.playing);
    if (st == null) return const SizedBox();
    final a = context.app;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 4),
      child: Neo(
        r: 22,
        pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        onTap: () => a.setNav(3),
        child: Row(children: [
          StationDot(st, size: 40),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 13, b: true)),
              Text(context.t('now'), maxLines: 1, style: ts(d, s: 11, m: true)),
            ]),
          ),
          GestureDetector(onTap: a.prev, child: Icon(Icons.skip_previous, color: d.mu)),
          const SizedBox(width: 6),
          Gloss(size: 36, onTap: a.toggle, child: Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 20)),
          const SizedBox(width: 6),
          GestureDetector(onTap: a.next, child: Icon(Icons.skip_next, color: d.mu)),
        ]),
      ),
    );
  }
}
