import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';
import 'player.dart';
import 'state.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cs = ColorScheme.fromSeed(
      seedColor: s.primary,
      brightness: s.dark ? Brightness.dark : Brightness.light,
    ).copyWith(
      primary: s.primary,
      secondary: s.accent,
      onPrimary: ThemeData.estimateBrightnessForColor(s.primary) == Brightness.dark ? Colors.white : Colors.black,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: s.cfg?.name ?? 'World Radio',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: cs,
        scaffoldBackgroundColor: s.dark ? const Color(0xFF0D0C1A) : const Color(0xFFF4F3FB),
      ),
      home: s.loading ? const _Splash() : (s.cfg == null ? const _Failed() : const Shell()),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) => const Scaffold(
        backgroundColor: Color(0xFF1F1F2E),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.radio, size: 72, color: Colors.white),
            SizedBox(height: 16),
            Text('World Radio', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600)),
            SizedBox(height: 24),
            CircularProgressIndicator(),
          ]),
        ),
      );
}

class _Failed extends StatelessWidget {
  const _Failed();
  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, size: 56),
            const SizedBox(height: 12),
            const Text('Could not reach the server'),
            Text(s.error ?? '', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
            const SizedBox(height: 16),
            FilledButton(onPressed: s.reload, child: const Text('Retry')),
          ]),
        ),
      ),
    );
  }
}

class Shell extends StatelessWidget {
  const Shell({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: IndexedStack(index: s.nav, children: const [HomePage(), CountriesPage(), FavsPage(), SettingsPage()]),
      bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
        if (s.current != null) const MiniPlayer(),
        NavigationBar(
          selectedIndex: s.nav,
          onDestinationSelected: s.setNav,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.radio), label: 'Stations'),
            NavigationDestination(icon: Icon(Icons.public), label: 'Countries'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favourites'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
          ],
        ),
      ]),
    );
  }
}

// ---------------------------------------------------------------- Home
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _search = false;
  final _ctl = TextEditingController();

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  Widget _chip(AppState s, String label, String slug) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(label), selected: s.tab == slug, onSelected: (_) => s.setTab(slug)),
      );

  void _filters(BuildContext c) {
    showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => Consumer<AppState>(builder: (ctx, s, __) {
        Widget group(String title, Map<String, int> m, String sel, void Function(String) on) {
          final e = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(padding: const EdgeInsets.only(top: 8, bottom: 6), child: Text(title, style: Theme.of(ctx).textTheme.titleSmall)),
            Wrap(spacing: 8, children: [
              for (final x in e.take(30))
                FilterChip(label: Text('${x.key}  ${x.value}'), selected: sel == x.key, onSelected: (v) => on(v ? x.key : '')),
            ]),
          ]);
        }

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              group('Country', s.countsBy((x) => x.country), s.country, s.setCountry),
              group('Language', s.countsBy((x) => x.language), s.language, s.setLanguage),
              const SizedBox(height: 16),
              Row(children: [
                TextButton(onPressed: s.clearFilters, child: const Text('Reset')),
                const Spacer(),
                FilledButton(onPressed: () => Navigator.pop(ctx), child: Text('Show ${s.visible.length} radios')),
              ]),
            ]),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cfg = s.cfg!;
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
          child: Row(children: [
            Logo(url: cfg.logo, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(cfg.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                Text(cfg.tagline, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
            IconButton(
              icon: Icon(_search ? Icons.close : Icons.search),
              onPressed: () => setState(() {
                _search = !_search;
                if (!_search) {
                  _ctl.clear();
                  s.setQuery('');
                }
              }),
            ),
            IconButton(
              icon: Badge(isLabelVisible: s.country.isNotEmpty || s.language.isNotEmpty, child: const Icon(Icons.tune)),
              onPressed: () => _filters(context),
            ),
          ]),
        ),
        if (_search)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: TextField(
              controller: _ctl,
              autofocus: true,
              onChanged: s.setQuery,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search radios',
                filled: true,
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
              ),
            ),
          ),
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            children: [_chip(s, 'All', 'all'), for (final t in cfg.tabs) _chip(s, t.name, t.slug)],
          ),
        ),
        Expanded(child: StationList(s.visible)),
      ]),
    );
  }
}

class StationList extends StatelessWidget {
  final List<Station> items;
  const StationList(this.items, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(s.stations.isEmpty ? 'No stations loaded.\n${s.error ?? ''}' : 'No radios found', textAlign: TextAlign.center),
        ),
      );
    }
    if (s.layout == 'grid') {
      return GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 130, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
        itemCount: items.length,
        itemBuilder: (_, i) => StationCard(items[i], items),
      );
    }
    return ListView.builder(itemCount: items.length, itemBuilder: (_, i) => StationTile(items[i], items));
  }
}

class StationTile extends StatelessWidget {
  final Station st;
  final List<Station> queue;
  const StationTile(this.st, this.queue, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cur = s.current?.id == st.id;
    return ListTile(
      onTap: () => s.tap(st, queue),
      leading: Logo(url: st.logo, size: 48),
      title: Text(st.name,
          maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w600, color: cur ? s.primary : null)),
      subtitle: Text([st.country, st.genre, if (st.bitrate > 0) '${st.bitrate} kbps'].where((e) => e.isNotEmpty).join(' · '),
          maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(
          icon: Icon(s.isFav(st) ? Icons.favorite : Icons.favorite_border, color: s.isFav(st) ? Colors.redAccent : null),
          onPressed: () => s.toggleFav(st),
        ),
        Icon(cur && s.playing ? Icons.graphic_eq : Icons.play_circle_outline, color: cur ? s.primary : null),
      ]),
    );
  }
}

class StationCard extends StatelessWidget {
  final Station st;
  final List<Station> queue;
  const StationCard(this.st, this.queue, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: () => s.tap(st, queue),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(child: LayoutBuilder(builder: (_, bc) => Logo(url: st.logo, size: bc.maxWidth, circle: false))),
                Positioned(
                  top: 0,
                  right: 0,
                  child: GestureDetector(
                    onTap: () => s.toggleFav(st),
                    child: Icon(s.isFav(st) ? Icons.favorite : Icons.favorite_border, size: 20, color: s.isFav(st) ? Colors.redAccent : Colors.white),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 6),
            Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            Text(st.country, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10)),
          ]),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Countries / Favourites
class CountriesPage extends StatelessWidget {
  const CountriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final e = s.countsBy((x) => x.country).entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return SafeArea(
      child: ListView(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Text('Countries', style: Theme.of(context).textTheme.headlineSmall)),
        for (final x in e)
          ListTile(
            leading: CircleAvatar(
              backgroundColor: s.primary,
              child: Text(x.key.substring(0, x.key.length < 2 ? x.key.length : 2).toUpperCase(),
                  style: TextStyle(color: Theme.of(context).colorScheme.onPrimary, fontSize: 12)),
            ),
            title: Text(x.key),
            subtitle: Text('${x.value} radios'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => s.pickCountry(x.key),
          ),
      ]),
    );
  }
}

class FavsPage extends StatelessWidget {
  const FavsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final f = s.favStations;
    return SafeArea(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Text('Favourites (${f.length})', style: Theme.of(context).textTheme.headlineSmall)),
        Expanded(
          child: f.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.favorite_border, size: 48, color: s.primary),
                  const SizedBox(height: 8),
                  const Text('No favourites yet'),
                  const Text('Tap the heart on any station'),
                ]))
              : StationList(f),
        ),
      ]),
    );
  }
}

// ---------------------------------------------------------------- Settings
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cfg = s.cfg!;
    final cs = Theme.of(context).colorScheme;
    Widget head(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
        child: Text(t, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w600)));
    Widget swatch(int i) {
      final p = i < 0 ? cfg.primary : cfg.themes[i].primary;
      final a = i < 0 ? cfg.accent : cfg.themes[i].accent;
      return GestureDetector(
        onTap: () => s.setTheme(i),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [p, a]),
            border: Border.all(width: 3, color: s.themeIdx == i ? cs.onSurface : Colors.transparent),
          ),
        ),
      );
    }

    return SafeArea(
      child: ListView(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), child: Text('Settings', style: Theme.of(context).textTheme.headlineSmall)),
        head('Appearance'),
        SwitchListTile(title: const Text('Dark mode'), value: s.dark, onChanged: s.setDark),
        if (cfg.letPick)
          ListTile(
            title: const Text('Theme color'),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Wrap(spacing: 12, runSpacing: 12, children: [for (var i = -1; i < cfg.themes.length; i++) swatch(i)]),
            ),
          ),
        ListTile(
          title: const Text('Station layout'),
          trailing: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'list', icon: Icon(Icons.view_list)),
              ButtonSegment(value: 'grid', icon: Icon(Icons.grid_view)),
            ],
            selected: {s.layout},
            onSelectionChanged: (v) => s.setLayout(v.first),
          ),
        ),
        head('Audio'),
        SwitchListTile(
            title: const Text('Autoplay on start'),
            subtitle: const Text('Resume the last station when the app opens'),
            value: s.autoplay,
            onChanged: s.setAutoplay),
        SwitchListTile(title: const Text('High quality audio'), subtitle: const Text('Prefer higher bitrate streams'), value: s.highQuality, onChanged: s.setHq),
        SwitchListTile(
            title: const Text('Auto reconnect'),
            subtitle: const Text('Retry up to 3 times on network loss'),
            value: s.autoReconnect,
            onChanged: s.setReconnect),
        head('About'),
        for (final p in cfg.pages)
          ListTile(
            title: Text(p.title),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => launchUrl(Uri.parse(p.url), mode: LaunchMode.externalApplication),
          ),
        if (cfg.submitUrl.isNotEmpty)
          ListTile(
            title: const Text('Submit a station'),
            trailing: const Icon(Icons.open_in_new),
            onTap: () => launchUrl(Uri.parse(cfg.submitUrl), mode: LaunchMode.externalApplication),
          ),
        Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('${cfg.name} · v1.0.0', style: Theme.of(context).textTheme.bodySmall))),
      ]),
    );
  }
}
