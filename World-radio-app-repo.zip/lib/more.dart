import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'design.dart';
import 'player.dart' show WavePreview;
import 'shell.dart' show LangPage, CountryPage;
import 'state.dart';
import 'i18n.dart';

const _gold = LinearGradient(colors: [Color(0xFFFFD86B), Color(0xFFFF9A3C)]);

Widget _body(Widget head, List<Widget> kids) => Scaffold(
      body: SafeArea(
        child: Column(children: [
          head,
          Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: kids)),
        ]),
      ),
    );

class _Row extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, sub;
  final Widget? trail;
  final VoidCallback? onTap;
  const _Row(this.icon, this.color, this.title, this.sub, {this.trail, this.onTap});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Neo(
        onTap: onTap,
        pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(children: [
          Well(icon, size: 40, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: ts(d, s: 13, b: true)),
              if (sub.isNotEmpty) Text(sub, style: ts(d, s: 11, m: true)),
            ]),
          ),
          if (trail != null) trail!,
        ]),
      ),
    );
  }
}

Widget _chev(Ds d) => Icon(Icons.chevron_right, size: 20, color: d.mu);
void _go(BuildContext c, Widget p) => Navigator.push(c, MaterialPageRoute(builder: (_) => p));
Future<void> _open(String u) => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);

// ------------------------------------------------------------ settings
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    final cfg = a.cfg!;
    String langName() => kLangs.firstWhere((l) => l[0] == a.lang, orElse: () => kLangs[0])[2];
    Widget radio(String v, IconData ic, String t, String s) => GestureDetector(
          onTap: () => a.setView(v),
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              Well(ic, size: 40, color: const Color(0xFF8D99AE)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: ts(d, s: 13, b: true)), Text(s, style: ts(d, s: 11, m: true))])),
              Container(
                width: 22,
                height: 22,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: a.view == v ? d.ac : d.mu, width: 2)),
                child: a.view == v ? Container(decoration: BoxDecoration(shape: BoxShape.circle, color: d.ac)) : null,
              ),
            ]),
          ),
        );
    return ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 24), children: [
      Text(a.t('set'), style: ts(d, s: 18, b: true)),
      const SizedBox(height: 10),
      Neo(
        onTap: () => _go(context, const VipPage()),
        pad: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(children: [
          Gloss(size: 40, grad: _gold, child: const Icon(Icons.workspace_premium, color: Colors.white, size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(a.t('vip'), style: ts(d, s: 13, b: true)), Text('from \$2.99 / month', style: ts(d, s: 11, m: true))])),
          _chev(d),
        ]),
      ),
      Label(a.t('appear')),
      _Row(Icons.dark_mode, const Color(0xFF4DA3FF), 'Dark Mode', 'Use dark theme', trail: Tog(a.dark, a.setDark)),
      _Row(Icons.favorite, const Color(0xFFFF5D8F), 'Favourite Tab on Launch', 'Open with favourites selected', trail: Tog(a.favLaunch, a.setFavLaunch)),
      _Row(Icons.play_arrow, const Color(0xFF34C77B), 'Autoplay on Start', 'Resume last station when app opens', trail: Tog(a.autoplay, a.setAutoplay)),
      const Label('Playlist theme'),
      Neo(
        pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        child: Column(children: [
          radio('list', Icons.view_list, 'List', 'Vertical scrollable list'),
          radio('grid', Icons.grid_view, 'Grid', '3-column image grid'),
          radio('classic', Icons.menu, 'Classic', 'Simple text list, no images'),
        ]),
      ),
      Label(a.t('audio')),
      _Row(Icons.music_note, const Color(0xFF2DE2C0), 'High Quality Audio', 'Prefer higher bitrate streams', trail: Tog(a.hq, a.setHq)),
      _Row(Icons.refresh, const Color(0xFF8F80FF), 'Auto Reconnect', 'Retry up to 3 times on network loss', trail: Tog(a.reconnect, a.setReconnect)),
      _Row(Icons.equalizer, const Color(0xFF4DA3FF), 'Equalizer', 'Tune bands, bass boost and surround', trail: _chev(d), onTap: () => _go(context, const EqPage())),
      _Row(Icons.volume_up, const Color(0xFFFFB15D), 'Normalize volume', 'Same loudness everywhere', trail: Tog(a.normalize, a.setNormalize)),
      _Row(Icons.public, const Color(0xFF8F80FF), 'Data saver', 'Lower quality on mobile data', trail: Tog(a.dataSaver, a.setDataSaver)),
      const Label('Language & Region'),
      _Row(Icons.translate, const Color(0xFF4DA3FF), a.t('al'), 'Change the app language',
          trail: Row(mainAxisSize: MainAxisSize.min, children: [Text(langName(), style: ts(d, s: 11, m: true)), _chev(d)]), onTap: () => _go(context, const LangPage())),
      _Row(Icons.public, const Color(0xFF8F80FF), a.t('dcl'), 'Opens first on launch',
          trail: Row(mainAxisSize: MainAxisSize.min, children: [Text(a.homeCountry, style: ts(d, s: 11, m: true)), _chev(d)]), onTap: () => _go(context, const CountryPage())),
      const Label('Player'),
      _Row(Icons.graphic_eq, const Color(0xFF2DE2C0), a.t('wave'), 'Bars, wave or dots', trail: _chev(d), onTap: () => _go(context, const PersonalizePage())),
      _Row(Icons.palette, const Color(0xFFC77DFF), a.t('pcol'), 'Accent color and beat reaction', trail: _chev(d), onTap: () => _go(context, const PersonalizePage())),
      Label(a.t('notif')),
      _Row(Icons.notifications, const Color(0xFFFF7A59), 'Programme Alerts', 'Schedule updates and announcements', trail: Tog(a.alerts, a.setAlerts)),
      _Row(Icons.battery_full, const Color(0xFF34C77B), 'Battery Optimization', 'Keep playing in the background',
          trail: _chev(d),
          onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Android Settings > Apps > this app > Battery > Unrestricted')))),
      Label(a.t('about')),
      _Row(Icons.shield_outlined, const Color(0xFF8F80FF), a.t('privacy'), 'How your data is handled', trail: _chev(d), onTap: () => _go(context, const PrivacyPage())),
      for (final p in cfg.pages)
        _Row(Icons.info_outline, const Color(0xFF8D99AE), p.title, '', trail: Icon(Icons.open_in_new, size: 16, color: d.mu), onTap: () => _open(p.url)),
      if (cfg.submitUrl.isNotEmpty)
        _Row(Icons.add_circle_outline, const Color(0xFF34C77B), 'Submit a station', '', trail: Icon(Icons.open_in_new, size: 16, color: d.mu), onTap: () => _open(cfg.submitUrl)),
      Padding(padding: const EdgeInsets.all(18), child: Center(child: Text('${cfg.name} · v1.0.0', style: ts(d, s: 11, m: true)))),
    ]);
  }
}

// ------------------------------------------------------------ personalize
class PersonalizePage extends StatelessWidget {
  const PersonalizePage({super.key});

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    final sw = a.swatches;
    Widget seg(String label, IconData ic, bool on, VoidCallback f) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Neo(sel: on, pad: const EdgeInsets.symmetric(vertical: 12), onTap: f, child: Column(children: [Well(ic), const SizedBox(height: 4), Text(label, style: ts(d, s: 12))])),
          ),
        );
    return _body(Head(a.t('pers')), [
      Label(a.t('theme')),
      Row(children: [seg('Dark', Icons.dark_mode, a.dark, () => a.setDark(true)), seg('Light', Icons.light_mode, !a.dark, () => a.setDark(false))]),
      Label(a.t('wave')),
      Neo(pad: const EdgeInsets.all(8), child: const WavePreview()),
      const SizedBox(height: 12),
      Row(children: [
        seg('Bars', Icons.bar_chart, a.wave == 'bars', () => a.setWave('bars')),
        seg('Wave', Icons.waves, a.wave == 'wave', () => a.setWave('wave')),
        seg('Dots', Icons.more_horiz, a.wave == 'circle', () => a.setWave('circle')),
      ]),
      Label(a.t('al')),
      Wrap(spacing: 8, runSpacing: 8, children: [for (final l in kLangs) Pill(l[2], on: a.lang == l[0], onTap: () => a.setLang(l[0]))]),
      Label(a.t('dcl')),
      Wrap(spacing: 14, runSpacing: 14, children: [
        for (final c in a.countries.take(30))
          GestureDetector(
            onTap: () => a.setDefCountry(c.key),
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: a.homeCountry == c.key ? d.ac : Colors.transparent, width: 2)),
              child: FlagC(c.key, size: 40),
            ),
          ),
      ]),
      Label(a.t('pcol')),
      Wrap(spacing: 16, runSpacing: 14, children: [
        for (var i = 0; i < sw.length; i++)
          GestureDetector(
            onTap: () => a.setAccent(i),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: sw[i]),
                border: Border.all(color: a.accentIdx == i ? d.tx : Colors.transparent, width: 2.5),
                boxShadow: [BoxShadow(color: d.sh, offset: const Offset(3, 4), blurRadius: 8)],
              ),
            ),
          ),
      ]),
      const SizedBox(height: 14),
      Neo(
        pad: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        child: Column(children: [
          Row(children: [Expanded(child: Text(a.t('beat'), style: ts(d, s: 13, b: true))), Tog(a.beatOn, a.setBeatOn)]),
          Row(children: [
            SizedBox(width: 110, child: Text(a.t('sens'), style: ts(d, s: 11, m: true))),
            Expanded(
              child: Slider(value: a.beat.clamp(0.0, 2.0).toDouble(), min: 0, max: 2, activeColor: d.ac, onChanged: a.setBeat),
            ),
          ]),
        ]),
      ),
    ]);
  }
}

// ------------------------------------------------------------ equalizer
class EqPage extends StatelessWidget {
  const EqPage({super.key});

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    const freq = ['60', '230', '910', '3.6k', '14k'];
    return _body(
      Head(a.t('eq'), right: GestureDetector(onTap: () => a.setPreset('Normal'), child: Icon(Icons.refresh, color: d.ac))),
      [
        _Row(Icons.equalizer, const Color(0xFF4DA3FF), a.t('eq'), 'Applied to all playback', trail: Tog(a.eqOn, a.setEqOn)),
        Neo(pad: const EdgeInsets.all(12), child: SizedBox(height: 110, child: CustomPaint(painter: _Curve(a.bands, d), size: Size.infinite))),
        const SizedBox(height: 10),
        Neo(
          pad: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            for (var i = 0; i < 5; i++)
              Expanded(
                child: Column(children: [
                  Text('${a.bands[i] > 0 ? '+' : ''}${a.bands[i]}', style: ts(d, s: 11, b: true)),
                  const SizedBox(height: 8),
                  _VSlider(a.bands[i], (v) => a.setBand(i, v), d),
                  const SizedBox(height: 8),
                  Text(freq[i], style: ts(d, s: 11, m: true)),
                ]),
              ),
          ]),
        ),
        const Label('Presets'),
        SizedBox(
          height: 38,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final p in kPresets.keys) Padding(padding: const EdgeInsets.only(right: 8), child: Pill(p, on: a.preset == p, onTap: () => a.setPreset(p))),
          ]),
        ),
        const SizedBox(height: 12),
        _Row(Icons.volume_up, const Color(0xFFFFB15D), 'Bass boost', 'Fuller low end', trail: Tog(a.bassBoost, a.setBassBoost)),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('Equalizer works on Android. On iPhone the settings are saved but the system does not allow live audio effects.', style: ts(d, s: 10, m: true)),
        ),
      ],
    );
  }
}

class _VSlider extends StatelessWidget {
  final int v;
  final ValueChanged<int> on;
  final Ds d;
  const _VSlider(this.v, this.on, this.d);

  void _set(double dy) => on((12 - (dy / 150).clamp(0.0, 1.0) * 24).round());

  @override
  Widget build(BuildContext context) => GestureDetector(
        onVerticalDragStart: (e) => _set(e.localPosition.dy),
        onVerticalDragUpdate: (e) => _set(e.localPosition.dy),
        onTapDown: (e) => _set(e.localPosition.dy),
        child: SizedBox(width: 40, height: 150, child: CustomPaint(painter: _VPaint(v, d))),
      );
}

class _VPaint extends CustomPainter {
  final int v;
  final Ds d;
  _VPaint(this.v, this.d);

  @override
  void paint(Canvas c, Size s) {
    final x = s.width / 2, y = (12 - v) / 24 * s.height;
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 4, 0, 8, s.height), const Radius.circular(4)), Paint()..color = d.bg);
    final top = y < s.height / 2 ? y : s.height / 2, bot = y < s.height / 2 ? s.height / 2 : y;
    c.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(x - 4, top, 8, bot - top), const Radius.circular(4)),
      Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [d.ac, d.a2]).createShader(Rect.fromLTWH(0, 0, s.width, s.height)),
    );
    c.drawCircle(Offset(x, y), 11, Paint()..color = d.cd);
    c.drawCircle(Offset(x, y), 11, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = d.ac);
  }

  @override
  bool shouldRepaint(_VPaint o) => o.v != v || o.d != d;
}

class _Curve extends CustomPainter {
  final List<int> b;
  final Ds d;
  _Curve(this.b, this.d);

  @override
  void paint(Canvas c, Size s) {
    for (var i = 0; i < 5; i++) {
      final y = 7 + i * (s.height - 14) / 4;
      c.drawLine(Offset(0, y), Offset(s.width, y), Paint()..color = d.mu.withOpacity(.2));
    }
    double px(int i) => 8 + i * (s.width - 16) / 4;
    double py(int i) => s.height / 2 - b[i] * (s.height / 2 - 7) / 12;
    final p = Path()..moveTo(px(0), py(0));
    for (var i = 1; i < 5; i++) {
      final m = (px(i - 1) + px(i)) / 2;
      p.cubicTo(m, py(i - 1), m, py(i), px(i), py(i));
    }
    final f = Path.from(p)..lineTo(px(4), s.height)..lineTo(px(0), s.height)..close();
    c.drawPath(f, Paint()..color = d.ac.withOpacity(.15));
    c.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5..color = d.ac);
    for (var i = 0; i < 5; i++) {
      c.drawCircle(Offset(px(i), py(i)), 4, Paint()..color = d.ac);
    }
  }

  @override
  bool shouldRepaint(_Curve o) => true;
}

// ------------------------------------------------------------ privacy
class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    Widget item(IconData ic, Color c, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(children: [Well(ic, size: 36, color: c), const SizedBox(width: 12), Expanded(child: Text(t, style: ts(d, s: 12)))]),
        );
    final pol = a.cfg!.pages.where((p) => p.title.toLowerCase().contains('privacy')).toList();
    return _body(Head(a.t('privacy')), [
      Neo(
        pad: const EdgeInsets.all(14),
        child: Row(children: [
          Well(Icons.shield_outlined, size: 48, color: d.ac),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${a.cfg!.name} - ${a.t('privacy')}', style: ts(d, s: 13, b: true)), Text('App v1.0.0', style: ts(d, s: 11, m: true))])),
        ]),
      ),
      const Label('At a glance'),
      Neo(
        pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Column(children: [
          item(Icons.check, const Color(0xFF34C77B), 'No account or sign-in. We never ask for your name, email or exact location.'),
          item(Icons.list, const Color(0xFF4DA3FF), 'Favourites, history and settings stay on your device.'),
          item(Icons.workspace_premium, const Color(0xFFFFB15D), 'The free plan may show ads. VIP removes them.'),
          item(Icons.shield_outlined, const Color(0xFF8F80FF), 'Crash reports are anonymous and only used to fix bugs.'),
          item(Icons.lock_outline, const Color(0xFFC77DFF), 'We never sell your data, and stream links are never shared.'),
        ]),
      ),
      if (pol.isNotEmpty) ...[const SizedBox(height: 16), Cta('Read the full policy', onTap: () => _open(pol.first.url))],
    ]);
  }
}

// ------------------------------------------------------------ VIP
class VipPage extends StatefulWidget {
  const VipPage({super.key});
  @override
  State<VipPage> createState() => _VipPageState();
}

class _VipPageState extends State<VipPage> {
  bool yearly = true;

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    Widget feat(String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 9),
          child: Row(children: [Well(Icons.check, size: 32, color: d.ac), const SizedBox(width: 12), Text(t, style: ts(d, s: 13, b: true))]),
        );
    Widget plan(bool y, String label, String price, String per) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Stack(clipBehavior: Clip.none, alignment: Alignment.topCenter, children: [
              Neo(
                sel: yearly == y,
                pad: const EdgeInsets.fromLTRB(8, 20, 8, 14),
                onTap: () => setState(() => yearly = y),
                child: SizedBox(width: double.infinity, child: Column(children: [Text(label, style: ts(d, s: 11, m: true)), Text(price, style: ts(d, s: 22, b: true)), Text(per, style: ts(d, s: 11, m: true))])),
              ),
              if (y)
                Positioned(
                  top: -9,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                    decoration: BoxDecoration(gradient: _gold, borderRadius: BorderRadius.circular(99)),
                    child: Text(a.t('best'), style: const TextStyle(color: Color(0xFF2B1A00), fontSize: 10, fontWeight: FontWeight.w600)),
                  ),
                ),
            ]),
          ),
        );
    return _body(Head(a.t('vip')), [
      const SizedBox(height: 10),
      Center(child: Gloss(size: 72, grad: _gold, glow: 24, child: const Icon(Icons.workspace_premium, color: Colors.white, size: 34))),
      const SizedBox(height: 10),
      Center(child: Text('${a.cfg!.name} VIP', style: ts(d, s: 18, b: true))),
      const SizedBox(height: 14),
      Neo(pad: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), child: Column(children: [feat(a.t('noads')), feat(a.t('hd')), feat(a.t('rec'))])),
      const SizedBox(height: 22),
      Row(children: [plan(false, a.t('month'), '\$2.99', '/ mo'), plan(true, a.t('year'), '\$19.99', '/ yr')]),
      const SizedBox(height: 22),
      Cta(a.t('subs'), gold: true, onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Subscriptions are not enabled yet.')))),
    ]);
  }
}
