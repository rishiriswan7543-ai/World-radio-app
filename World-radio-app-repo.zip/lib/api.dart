import 'dart:convert';
import 'dart:ui' show Color;
import 'package:http/http.dart' as http;

const kBase = 'https://wpradio.anowhosting.com';
const kApi = '$kBase/api/app.php';
const kActionConfig = 'config'; // confirmed from your API
const kActionStations = 'stations'; // ASSUMED - change to your real action name

Color hexColor(String? h, [Color fb = const Color(0xFFF5B830)]) {
  if (h == null || !h.startsWith('#')) return fb;
  var x = h.substring(1);
  if (x.length == 3) x = x.split('').map((c) => c + c).join();
  final v = int.tryParse(x, radix: 16);
  return v == null ? fb : Color(0xFF000000 | v);
}

String slug(String s) => s
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
    .replaceAll(RegExp(r'^-+|-+$'), '');

class ThemeOpt {
  final String name;
  final Color primary, accent;
  ThemeOpt(this.name, this.primary, this.accent);
}

class TabOpt {
  final String name, slug;
  final int count;
  TabOpt(this.name, this.slug, this.count);
}

class PageOpt {
  final String title, url;
  PageOpt(this.title, this.url);
}

class AppConfig {
  final String name, tagline, logo, submitUrl, layout;
  final Color primary, accent;
  final bool letPick, darkDefault, autoplay, autoReconnect, highQuality, showFavTab;
  final List<ThemeOpt> themes;
  final List<TabOpt> tabs;
  final List<PageOpt> pages;

  AppConfig({
    required this.name, required this.tagline, required this.logo, required this.submitUrl,
    required this.layout, required this.primary, required this.accent, required this.letPick,
    required this.darkDefault, required this.autoplay, required this.autoReconnect,
    required this.highQuality, required this.showFavTab, required this.themes,
    required this.tabs, required this.pages,
  });

  factory AppConfig.fromJson(Map<String, dynamic> j) {
    final app = Map<String, dynamic>.from((j['app'] as Map?) ?? {});
    List<T> list<T>(String k, T Function(Map<String, dynamic>) f) =>
        ((j[k] as List?) ?? []).whereType<Map>().map((e) => f(Map<String, dynamic>.from(e))).toList();
    bool flag(String k, bool d) => app[k] is bool ? app[k] as bool : d;
    return AppConfig(
      name: '${app['name'] ?? j['shortName'] ?? 'World Radio'}',
      tagline: '${app['tagline'] ?? j['tagline'] ?? ''}',
      logo: '${app['logo'] ?? j['logo'] ?? ''}',
      submitUrl: '${j['submitUrl'] ?? ''}',
      layout: '${app['layout'] ?? 'list'}',
      primary: hexColor(j['primary'] as String?),
      accent: hexColor(j['accent'] as String?, const Color(0xFFE4572E)),
      letPick: j['letUserPickColor'] == true,
      darkDefault: flag('darkDefault', j['defaultMode'] == 'dark'),
      autoplay: flag('autoplay', true),
      autoReconnect: flag('autoReconnect', true),
      highQuality: flag('highQuality', true),
      showFavTab: flag('showFavouriteTab', true),
      themes: list('themes', (t) => ThemeOpt('${t['name']}', hexColor(t['primary'] as String?), hexColor(t['accent'] as String?))),
      tabs: list('tabs', (t) => TabOpt('${t['name']}', '${t['slug']}', (t['count'] as num?)?.toInt() ?? 0)),
      pages: list('pages', (t) => PageOpt('${t['title']}', '${t['url']}')),
    );
  }
}

class Station {
  final String id, name, stream, logo, country, language, genre, tags;
  final int bitrate;
  Station({
    required this.id, required this.name, required this.stream, required this.logo,
    required this.country, required this.language, required this.genre,
    required this.tags, required this.bitrate,
  });

  static String _s(Map j, List<String> keys) {
    for (final k in keys) {
      final v = j[k];
      if (v == null) continue;
      if (v is List && v.isNotEmpty) return v.map((e) => e is Map ? '${e['name'] ?? ''}' : '$e').join(', ');
      if (v is Map) {
        if (v['name'] != null) return '${v['name']}';
        continue;
      }
      if ('$v'.trim().isNotEmpty) return '$v'.trim();
    }
    return '';
  }

  // ASSUMED field names - the parser tries several common ones. Adjust if needed.
  factory Station.fromJson(Map<String, dynamic> j) {
    final name = _s(j, ['name', 'title']);
    final id = _s(j, ['id', 'slug', 'uuid']);
    return Station(
      id: id.isEmpty ? name : id,
      name: name,
      stream: _s(j, ['stream', 'stream_url', 'streamUrl', 'url_resolved', 'url']),
      logo: _s(j, ['logo', 'image', 'favicon', 'icon', 'cover', 'thumbnail']),
      country: _s(j, ['country', 'country_name', 'countryName']),
      language: _s(j, ['language', 'lang']),
      genre: _s(j, ['genre', 'genres', 'category']),
      tags: _s(j, ['tags', 'tag']),
      bitrate: int.tryParse(_s(j, ['bitrate'])) ?? 0,
    );
  }

  List<String> get genreSlugs =>
      genre.split(RegExp(r'[,;/|]')).map((e) => slug(e.trim())).where((e) => e.isNotEmpty).toList();
}

class Api {
  static Future<dynamic> _get(String action) async {
    final uri = Uri.parse(kApi).replace(queryParameters: {'action': action});
    final r = await http.get(uri).timeout(const Duration(seconds: 25));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
    return jsonDecode(utf8.decode(r.bodyBytes));
  }

  static Future<AppConfig> config() async {
    final d = await _get(kActionConfig);
    if (d is! Map || d['ok'] != true) throw Exception('Bad config response');
    return AppConfig.fromJson(Map<String, dynamic>.from(d));
  }

  static Future<List<Station>> stations() async {
    final d = await _get(kActionStations);
    List raw = [];
    if (d is List) {
      raw = d;
    } else if (d is Map) {
      for (final k in ['stations', 'data', 'items', 'results']) {
        if (d[k] is List) {
          raw = d[k] as List;
          break;
        }
      }
    }
    return raw
        .whereType<Map>()
        .map((e) => Station.fromJson(Map<String, dynamic>.from(e)))
        .where((s) => s.stream.isNotEmpty && s.name.isNotEmpty)
        .toList();
  }
}
