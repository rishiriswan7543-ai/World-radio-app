import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';

class AppState extends ChangeNotifier {
  AppConfig? cfg;
  List<Station> stations = [];
  String? error;
  bool loading = true, dark = true, autoplay = true, autoReconnect = true, highQuality = true;
  int themeIdx = -1, nav = 0;
  String layout = 'list', tab = 'all', query = '', country = '', language = '';
  final Set<String> favs = {};
  late SharedPreferences prefs;

  final player = AudioPlayer();
  Station? current;
  List<Station> _queue = [];
  int _retry = 0;
  Timer? _sleepT;
  Duration? sleepLeft, sleepTotal;

  ThemeOpt? get _theme =>
      (cfg != null && themeIdx >= 0 && themeIdx < cfg!.themes.length) ? cfg!.themes[themeIdx] : null;
  Color get primary => _theme?.primary ?? cfg?.primary ?? const Color(0xFFF5B830);
  Color get accent => _theme?.accent ?? cfg?.accent ?? const Color(0xFFE4572E);
  bool get playing => player.playing;
  bool get buffering =>
      player.processingState == ProcessingState.loading || player.processingState == ProcessingState.buffering;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    favs.addAll(prefs.getStringList('favs') ?? []);
    player.playerStateStream.listen((st) {
      if (st.processingState == ProcessingState.ready) _retry = 0;
      notifyListeners();
    });
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) => _reconnect());
    await reload();
  }

  Future<void> reload() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final c = await Api.config();
      cfg = c;
      dark = prefs.getBool('dark') ?? c.darkDefault;
      layout = prefs.getString('layout') ?? c.layout;
      autoplay = prefs.getBool('autoplay') ?? c.autoplay;
      autoReconnect = prefs.getBool('reconnect') ?? c.autoReconnect;
      highQuality = prefs.getBool('hq') ?? c.highQuality;
      themeIdx = prefs.getInt('theme') ?? -1;
      stations = await Api.stations();
    } catch (e) {
      error = '$e';
    }
    loading = false;
    notifyListeners();
    final last = prefs.getString('last');
    if (autoplay && last != null && current == null) {
      final m = stations.where((s) => s.id == last);
      if (m.isNotEmpty) play(m.first, queue: stations);
    }
  }

  // ---------- filtering
  List<Station> get visible {
    final q = query.trim().toLowerCase();
    return stations.where((s) {
      if (tab != 'all' && !s.genreSlugs.contains(tab)) return false;
      if (country.isNotEmpty && s.country != country) return false;
      if (language.isNotEmpty && s.language != language) return false;
      return q.isEmpty || '${s.name} ${s.country} ${s.language} ${s.genre} ${s.tags}'.toLowerCase().contains(q);
    }).toList();
  }

  Map<String, int> countsBy(String Function(Station) f) {
    final m = <String, int>{};
    for (final s in stations) {
      final k = f(s);
      if (k.isNotEmpty) m[k] = (m[k] ?? 0) + 1;
    }
    return m;
  }

  void _n(void Function() f) {
    f();
    notifyListeners();
  }

  void setNav(int i) => _n(() => nav = i);
  void setTab(String t) => _n(() => tab = t);
  void setQuery(String q) => _n(() => query = q);
  void setCountry(String c) => _n(() => country = c);
  void setLanguage(String l) => _n(() => language = l);
  void clearFilters() => _n(() {
        country = '';
        language = '';
        tab = 'all';
      });
  void pickCountry(String c) => _n(() {
        country = c;
        tab = 'all';
        nav = 0;
      });

  // ---------- settings
  void setDark(bool v) => _n(() {
        dark = v;
        prefs.setBool('dark', v);
      });
  void setLayout(String v) => _n(() {
        layout = v;
        prefs.setString('layout', v);
      });
  void setAutoplay(bool v) => _n(() {
        autoplay = v;
        prefs.setBool('autoplay', v);
      });
  void setReconnect(bool v) => _n(() {
        autoReconnect = v;
        prefs.setBool('reconnect', v);
      });
  void setHq(bool v) => _n(() {
        highQuality = v;
        prefs.setBool('hq', v);
      });
  void setTheme(int i) => _n(() {
        themeIdx = i;
        prefs.setInt('theme', i);
      });

  // ---------- favourites
  bool isFav(Station s) => favs.contains(s.id);
  List<Station> get favStations => stations.where(isFav).toList();
  void toggleFav(Station s) => _n(() {
        favs.contains(s.id) ? favs.remove(s.id) : favs.add(s.id);
        prefs.setStringList('favs', favs.toList());
      });

  // ---------- playback
  Future<void> play(Station s, {List<Station>? queue}) async {
    current = s;
    if (queue != null) _queue = queue;
    prefs.setString('last', s.id);
    notifyListeners();
    try {
      await player.setAudioSource(AudioSource.uri(
        Uri.parse(s.stream),
        tag: MediaItem(
          id: s.id,
          title: s.name,
          album: s.country,
          artist: s.genre.isEmpty ? 'Live radio' : s.genre,
          artUri: s.logo.isEmpty ? null : Uri.tryParse(s.logo),
        ),
      ));
      player.play();
    } catch (_) {
      _reconnect();
    }
  }

  void tap(Station s, List<Station> q) => current?.id == s.id ? toggle() : play(s, queue: q);

  void toggle() {
    if (current == null) return;
    player.playing ? player.pause() : player.play();
  }

  void _step(int d) {
    if (current == null || _queue.isEmpty) return;
    final i = _queue.indexWhere((x) => x.id == current!.id);
    play(_queue[((i < 0 ? 0 : i) + d) % _queue.length]);
  }

  void next() => _step(1);
  void prev() => _step(-1);

  void _reconnect() {
    final s = current;
    if (!autoReconnect || s == null || _retry >= 3) return;
    _retry++;
    Future.delayed(const Duration(seconds: 2), () => play(s));
  }

  // ---------- sleep timer
  void setSleep(Duration? d) {
    _sleepT?.cancel();
    sleepLeft = d;
    sleepTotal = d;
    if (d != null) {
      _sleepT = Timer.periodic(const Duration(seconds: 1), (_) {
        sleepLeft = sleepLeft! - const Duration(seconds: 1);
        if (sleepLeft! <= Duration.zero) {
          player.pause();
          setSleep(null);
          return;
        }
        notifyListeners();
      });
    }
    notifyListeners();
  }
}
