import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';
import 'design.dart';
import 'i18n.dart';

const kPresets = <String, List<int>>{
  'Normal': [3, 0, 0, 0, 3],
  'Classical': [5, 3, -2, 4, 4],
  'Dance': [6, 0, 2, 4, 1],
  'Folk': [3, 0, 0, 2, -1],
  'Heavy Metal': [4, 1, 9, 3, 0],
  'Hip Hop': [5, 3, 0, 1, 3],
  'Jazz': [4, 2, -2, 2, 5],
  'Pop': [-1, 2, 5, 1, -2],
  'Rock': [5, 3, -1, 3, 5],
};

class AppState extends ChangeNotifier {
  AppConfig? cfg;
  List<Station> stations = [];
  List<MapEntry<String, int>> countries = [];
  String? error;
  bool loading = true, onboarded = false;
  late SharedPreferences prefs;

  // settings
  String lang = 'en', view = 'grid', sort = 'pop', wave = 'wave', defCountry = '';
  bool dark = true, autoplay = true, hq = true, reconnect = true, normalize = true;
  bool dataSaver = false, alerts = true, favLaunch = false, beatOn = false;
  double beat = 1;
  int accentIdx = 0, nav = 0;

  // filters
  String cat = '', genre = '', language = '', tag = '', query = '';
  bool searchOpen = false;
  List<Station>? _fc;
  final Set<String> favs = {};

  // equalizer
  List<int> bands = [3, 0, 0, 0, 3];
  bool eqOn = true, bassBoost = false;
  String preset = 'Normal';

  // player
  late final AndroidEqualizer eq = AndroidEqualizer();
  late final AudioPlayer player =
      AudioPlayer(audioPipeline: Platform.isAndroid ? AudioPipeline(androidAudioEffects: [eq]) : null);
  Station? current;
  bool playing = false, buffering = false;
  List<Station> _queue = [];
  int _retry = 0;
  Timer? _sleepT;
  final ValueNotifier<Duration?> sleepLeft = ValueNotifier(null);
  Duration? sleepTotal;

  // ---------- design tokens
  Ds? _ds;
  String _dk = '';
  List<List<Color>> get swatches => [
        const [Color(0xFF8F80FF), Color(0xFF2DE2C0)],
        ...?cfg?.themes.map((t) => [t.primary, t.accent]),
      ];
  Ds get ds {
    final k = '$dark$accentIdx${cfg == null}';
    if (_dk != k || _ds == null) {
      _dk = k;
      final sw = swatches;
      final c = sw[accentIdx < sw.length ? accentIdx : 0];
      _ds = Ds(dark, c[0], c[1]);
    }
    return _ds!;
  }

  String t(String k) => tr(lang, k);

  // ---------- load
  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    favs.addAll(prefs.getStringList('favs') ?? []);
    onboarded = prefs.getBool('onboarded') ?? false;
    lang = prefs.getString('lang') ?? 'en';
    defCountry = prefs.getString('country') ?? '';
    wave = prefs.getString('wave') ?? 'wave';
    sort = prefs.getString('sort') ?? 'pop';
    beatOn = prefs.getBool('beatOn') ?? false;
    beat = prefs.getDouble('beat') ?? 1;
    accentIdx = prefs.getInt('accent') ?? 0;
    normalize = prefs.getBool('normalize') ?? true;
    dataSaver = prefs.getBool('dataSaver') ?? false;
    alerts = prefs.getBool('alerts') ?? true;
    favLaunch = prefs.getBool('favLaunch') ?? false;
    player.playerStateStream.listen((st) {
      final b = st.processingState == ProcessingState.loading || st.processingState == ProcessingState.buffering;
      if (st.processingState == ProcessingState.ready) _retry = 0;
      if (st.playing != playing || b != buffering) {
        playing = st.playing;
        buffering = b;
        notifyListeners();
      }
    });
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace s) => _reconnect());
    await reload();
  }

  Future<void> reload() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final c = await Api.config();
      cfg = c;
      dark = prefs.getBool('dark') ?? c.darkDefault;
      view = prefs.getString('view') ?? (c.layout == 'grid' ? 'grid' : 'list');
      autoplay = prefs.getBool('autoplay') ?? c.autoplay;
      reconnect = prefs.getBool('reconnect') ?? c.autoReconnect;
      hq = prefs.getBool('hq') ?? c.highQuality;
      stations = await Api.stations();
      final m = <String, int>{};
      for (final s in stations) {
        if (s.country.isNotEmpty) m[s.country] = (m[s.country] ?? 0) + 1;
      }
      countries = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      _fc = null;
    } catch (e) {
      error = '$e';
    }
    loading = false;
    if (favLaunch) nav = 2;
    notifyListeners();
    final last = prefs.getString('last');
    if (autoplay && last != null && current == null) {
      final m = stations.where((s) => s.id == last);
      if (m.isNotEmpty) play(m.first, queue: stations);
    }
  }

  // ---------- generic persisted update
  void _u(void Function() f, [String? k, Object? v]) {
    f();
    if (k != null) {
      if (v is bool) {
        prefs.setBool(k, v);
      } else if (v is int) {
        prefs.setInt(k, v);
      } else if (v is double) {
        prefs.setDouble(k, v);
      } else if (v is String) {
        prefs.setString(k, v);
      }
    }
    notifyListeners();
  }

  void finishOnboarding() => _u(() => onboarded = true, 'onboarded', true);
  void setLang(String v) => _u(() => lang = v, 'lang', v);
  void setDark(bool v) => _u(() => dark = v, 'dark', v);
  void setAccent(int v) => _u(() => accentIdx = v, 'accent', v);
  void setWave(String v) => _u(() => wave = v, 'wave', v);
  void setBeatOn(bool v) => _u(() => beatOn = v, 'beatOn', v);
  void setBeat(double v) => _u(() => beat = v, 'beat', v);
  void setAutoplay(bool v) => _u(() => autoplay = v, 'autoplay', v);
  void setHq(bool v) => _u(() => hq = v, 'hq', v);
  void setReconnect(bool v) => _u(() => reconnect = v, 'reconnect', v);
  void setNormalize(bool v) => _u(() => normalize = v, 'normalize', v);
  void setDataSaver(bool v) => _u(() => dataSaver = v, 'dataSaver', v);
  void setAlerts(bool v) => _u(() => alerts = v, 'alerts', v);
  void setFavLaunch(bool v) => _u(() => favLaunch = v, 'favLaunch', v);
  void setView(String v) => _u(() => view = v, 'view', v);
  void setSort(String v) => _u(() {
        sort = v;
        _fc = null;
      }, 'sort', v);
  void setDefCountry(String v) => _u(() => defCountry = v, 'country', v);
  void setNav(int i) => _u(() => nav = i);
  void openSearch() => _u(() {
        nav = 1;
        searchOpen = true;
      });
  void setSearchOpen(bool v) => _u(() => searchOpen = v);

  // ---------- filters
  void _f(void Function() fn) {
    fn();
    _fc = null;
    notifyListeners();
  }

  void setCat(String c) => _f(() => cat = c);
  void setQuery(String q) => _f(() => query = q);
  void toggleFilter(String field, String v) => _f(() {
        if (field == 'genre') genre = genre == v ? '' : v;
        if (field == 'language') language = language == v ? '' : v;
        if (field == 'tag') tag = tag == v ? '' : v;
      });
  void clearFilter(String field) => _f(() {
        if (field == 'cat') cat = '';
        if (field == 'genre') genre = '';
        if (field == 'language') language = '';
        if (field == 'tag') tag = '';
        if (field == 'query') query = '';
      });
  void clearFilters() => _f(() {
        cat = genre = language = tag = query = '';
        sort = 'pop';
      });

  List<Station> get filtered => _fc ??= _compute();

  List<Station> _compute() {
    final q = query.trim().toLowerCase();
    final out = stations.where((s) {
      if (cat.isNotEmpty && !s.genreSlugs.contains(cat)) return false;
      if (genre.isNotEmpty && !s.genre.toLowerCase().contains(genre.toLowerCase())) return false;
      if (language.isNotEmpty && s.language != language) return false;
      if (tag.isNotEmpty && !s.tags.toLowerCase().contains(tag)) return false;
      return q.isEmpty || '${s.name} ${s.country} ${s.language} ${s.genre} ${s.tags}'.toLowerCase().contains(q);
    }).toList();
    switch (sort) {
      case 'az':
        out.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case 'za':
        out.sort((a, b) => b.name.toLowerCase().compareTo(a.name.toLowerCase()));
        break;
      case 'bh':
        out.sort((a, b) => b.bitrate.compareTo(a.bitrate));
        break;
      case 'bl':
        out.sort((a, b) => a.bitrate.compareTo(b.bitrate));
        break;
    }
    return out;
  }

  List<MapEntry<String, int>> topBy(Iterable<String> Function(Station) f, [int n = 12]) {
    final m = <String, int>{};
    for (final s in stations) {
      for (final k in f(s)) {
        if (k.isNotEmpty) m[k] = (m[k] ?? 0) + 1;
      }
    }
    final e = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return e.take(n).toList();
  }

  String get homeCountry => defCountry.isNotEmpty ? defCountry : (countries.isNotEmpty ? countries.first.key : '');

  // ---------- favourites
  bool isFav(Station s) => favs.contains(s.id);
  List<Station> get favStations => stations.where(isFav).toList();
  void toggleFav(Station s) => _u(() {
        favs.contains(s.id) ? favs.remove(s.id) : favs.add(s.id);
        prefs.setStringList('favs', favs.toList());
      });

  // ---------- playback
  Future<void> play(Station s, {List<Station>? queue}) async {
    current = s;
    if (queue != null) _queue = queue;
    prefs.setString('last', s.id);
    notifyListeners();
    try {
      await player.setAudioSource(AudioSource.uri(
        Uri.parse(s.stream),
        tag: MediaItem(
          id: s.id,
          title: s.name,
          album: s.country,
          artist: s.genre.isEmpty ? 'Live radio' : s.genre,
          artUri: s.logo.isEmpty ? null : Uri.tryParse(s.logo),
        ),
      ));
      player.play();
      applyEq();
    } catch (_) {
      _reconnect();
    }
  }

  void tap(Station s, List<Station> q) => current?.id == s.id ? toggle() : play(s, queue: q);

  void toggle() {
    if (current == null) return;
    player.playing ? player.pause() : player.play();
  }

  void _step(int d) {
    if (current == null) return;
    final q = _queue.isEmpty ? stations : _queue;
    if (q.isEmpty) return;
    final i = q.indexWhere((x) => x.id == current!.id);
    play(q[((i < 0 ? 0 : i) + d) % q.length]);
  }

  void next() => _step(1);
  void prev() => _step(-1);

  void _reconnect() {
    final s = current;
    if (!reconnect || s == null || _retry >= 3) return;
    _retry++;
    Future.delayed(const Duration(seconds: 2), () => play(s));
  }

  // ---------- equalizer (real on Android; saved on iOS)
  Future<void> applyEq() async {
    if (!Platform.isAndroid) return;
    try {
      await eq.setEnabled(eqOn);
      final p = await eq.parameters;
      for (var i = 0; i < p.bands.length && i < bands.length; i++) {
        final g = (bands[i] + (bassBoost ? (i == 0 ? 6 : (i == 1 ? 3 : 0)) : 0)) * (p.maxDecibels / 12);
        await p.bands[i].setGain(g.clamp(p.minDecibels, p.maxDecibels).toDouble());
      }
    } catch (_) {}
  }

  void setBand(int i, int v) {
    bands[i] = v.clamp(-12, 12).toInt();
    preset = 'Custom';
    notifyListeners();
    applyEq();
  }

  void setPreset(String name) {
    final p = kPresets[name];
    if (p == null) return;
    bands = List.of(p);
    preset = name;
    notifyListeners();
    applyEq();
  }

  void setBassBoost(bool v) {
    bassBoost = v;
    notifyListeners();
    applyEq();
  }

  void setEqOn(bool v) {
    eqOn = v;
    notifyListeners();
    applyEq();
  }

  // ---------- sleep timer
  void setSleep(Duration? d) {
    _sleepT?.cancel();
    sleepTotal = d;
    sleepLeft.value = d;
    if (d != null) {
      _sleepT = Timer.periodic(const Duration(seconds: 1), (_) {
        final n = sleepLeft.value! - const Duration(seconds: 1);
        if (n <= Duration.zero) {
          player.pause();
          setSleep(null);
        } else {
          sleepLeft.value = n;
        }
      });
    }
  }
}
