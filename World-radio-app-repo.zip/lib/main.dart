import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'state.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Must run before the first AudioPlayer is created (background + lock screen controls).
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.anowhosting.worldradios.audio',
    androidNotificationChannelName: 'Radio playback',
    androidNotificationOngoing: true,
  );
  final st = AppState();
  runApp(ChangeNotifierProvider.value(value: st, child: const App()));
  st.init();
}
