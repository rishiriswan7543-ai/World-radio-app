import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'api.dart';
import 'design.dart';
import 'shell.dart' show LangPage;
import 'state.dart';

const _red = Color(0xFFFF4D6D);
const _lt = {
  'Tamil': 'த', 'Sinhala': 'සි', 'English': 'En', 'Hindi': 'हि', 'Japanese': '日', 'German': 'De', 'French': 'Fr',
  'Telugu': 'తె', 'Malayalam': 'മ', 'Kannada': 'ಕ', 'Arabic': 'ع', 'Spanish': 'Es', 'Chinese': '中', 'Korean': '한',
  'Russian': 'Ру', 'Urdu': 'اُ', 'Bengali': 'বা', 'Portuguese': 'Pt', 'Italian': 'It', 'Turkish': 'Tr',
};

class IBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const IBtn(this.icon, this.onTap, {super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: d.cd,
          border: d.dark ? null : Border.all(color: d.ac.withOpacity(.28)),
          boxShadow: [
            BoxShadow(color: d.sh, offset: const Offset(4, 4), blurRadius: 9),
            BoxShadow(color: d.hi, offset: const Offset(-3, -3), blurRadius: 7),
          ],
        ),
        child: Icon(icon, size: 18, color: d.tx),
      ),
    );
  }
}

Widget topBar(BuildContext c, {required String title, String? sub, List<Widget> actions = const []}) {
  final d = c.d;
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
    child: Row(children: [
      Gloss(size: 36, child: const Icon(Icons.radio, color: Colors.white, size: 18)),
      const SizedBox(width: 10),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 16, b: true)),
          if (sub != null && sub.isNotEmpty) Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 11, m: true)),
        ]),
      ),
      for (final a in actions) ...[const SizedBox(width: 8), a],
    ]),
  );
}

// ------------------------------------------------------------ station widgets
class StationCard extends StatelessWidget {
  final Station st;
  final List<Station> queue;
  const StationCard(this.st, this.queue, {super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final fav = context.select<AppState, bool>((s) => s.isFav(st));
    final cur = context.select<AppState, bool>((s) => s.current?.id == st.id);
    return Neo(
      pad: const EdgeInsets.all(6),
      sel: cur,
      onTap: () => context.app.tap(st, queue),
      child: Column(children: [
        Expanded(
          child: Stack(children: [
            Positioned.fill(child: StationArt(st)),
            Positioned(
              top: 4,
              right: 4,
              child: GestureDetector(
                onTap: () => context.app.toggleFav(st),
                child: Icon(fav ? Icons.favorite : Icons.favorite_border, size: 18, color: fav ? _red : Colors.white),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 6),
        Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 11, b: true)),
        Text(st.genre.isEmpty ? st.country : st.genre, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 10, m: true)),
      ]),
    );
  }
}

class StationRow extends StatelessWidget {
  final Station st;
  final List<Station> queue;
  const StationRow(this.st, this.queue, {super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final fav = context.select<AppState, bool>((s) => s.isFav(st));
    final cur = context.select<AppState, bool>((s) => s.current?.id == st.id);
    final playing = context.select<AppState, bool>((s) => s.playing && s.current?.id == st.id);
    return Neo(
      sel: cur,
      pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      onTap: () => context.app.tap(st, queue),
      child: Row(children: [
        StationDot(st, size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 13, b: true)),
            Text([st.genre, st.language, if (st.bitrate > 0) '${st.bitrate} kbps'].where((e) => e.isNotEmpty).join(' · '),
                maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 11, m: true)),
          ]),
        ),
        GestureDetector(
          onTap: () => context.app.toggleFav(st),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Icon(fav ? Icons.favorite : Icons.favorite_border, size: 20, color: fav ? _red : d.mu),
          ),
        ),
        Gloss(size: 34, child: Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 18)),
      ]),
    );
  }
}

Widget stationsView(List<Station> items, String view, {EdgeInsets pad = const EdgeInsets.fromLTRB(16, 8, 16, 90)}) {
  if (view == 'grid') {
    return GridView.builder(
      padding: pad,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: .78),
      itemCount: items.length,
      itemBuilder: (_, i) => RepaintBoundary(child: StationCard(items[i], items)),
    );
  }
  return ListView.builder(
    padding: pad,
    itemCount: items.length,
    itemBuilder: (c, i) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: RepaintBoundary(
        child: view == 'classic' ? _ClassicRow(items[i], items) : StationRow(items[i], items),
      ),
    ),
  );
}

class _ClassicRow extends StatelessWidget {
  final Station st;
  final List<Station> queue;
  const _ClassicRow(this.st, this.queue);

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final cur = context.select<AppState, bool>((s) => s.current?.id == st.id);
    return GestureDetector(
      onTap: () => context.app.tap(st, queue),
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: d.mu.withOpacity(.2)))),
        child: Row(children: [
          Expanded(child: Text(st.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 13, b: true, c: cur ? d.ac : null))),
          Text(st.bitrate > 0 ? '${st.bitrate} kbps' : '', style: ts(d, s: 11, m: true)),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------ home (countries)
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final PageController _pc;
  String _sel = '', _last = '', _lang = '';

  @override
  void initState() {
    super.initState();
    final a = context.read<AppState>();
    _sel = _last = a.homeCountry;
    _pc = PageController(
        viewportFraction: .26, initialPage: max(0, a.countries.indexWhere((e) => e.key == a.homeCountry)));
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  Widget _flag(int i, List<MapEntry<String, int>> cs) => AnimatedBuilder(
        animation: _pc,
        builder: (_, __) {
          final page = (_pc.hasClients && _pc.position.haveDimensions ? _pc.page : null) ?? _pc.initialPage.toDouble();
          final o = i - page, a = o.abs();
          final sc = (1.35 - .3 * a).clamp(.7, 1.35).toDouble();
          return Center(
            child: Opacity(
              opacity: (1 - a * .22).clamp(.25, 1.0).toDouble(),
              child: Transform(
                alignment: Alignment.center,
                transform: Matrix4.identity()
                  ..setEntry(3, 2, .002)
                  ..rotateY(-o * .5)
                  ..scale(sc, sc, 1.0),
                child: GestureDetector(
                  onTap: () => _pc.animateToPage(i, duration: const Duration(milliseconds: 300), curve: Curves.easeOut),
                  child: FlagC(cs[i].key, size: 56),
                ),
              ),
            ),
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final a = context.app;
    final cs = context.select<AppState, List<MapEntry<String, int>>>((s) => s.countries);
    final all = context.select<AppState, List<Station>>((s) => s.stations);
    final hc = context.select<AppState, String>((s) => s.homeCountry);
    final name = context.select<AppState, String>((s) => s.cfg?.name ?? 'World Radio');
    if (hc != _last) {
      _last = hc;
      _sel = hc;
      final i = cs.indexWhere((e) => e.key == hc);
      if (i >= 0) WidgetsBinding.instance.addPostFrameCallback((_) => _pc.hasClients ? _pc.jumpToPage(i) : null);
    }
    final inCountry = all.where((s) => s.country == _sel).toList();
    final langs = <String, int>{};
    for (final s in inCountry) {
      if (s.language.isNotEmpty) langs[s.language] = (langs[s.language] ?? 0) + 1;
    }
    final shown = _lang.isEmpty ? inCountry : inCountry.where((s) => s.language == _lang).toList();
    return Column(children: [
      topBar(context, title: name, actions: [
        IBtn(Icons.language, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LangPage()))),
        IBtn(Icons.search, a.openSearch),
      ]),
      Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(left: 18), child: Label(context.t('home')))),
      SizedBox(
        height: 104,
        child: PageView.builder(
          controller: _pc,
          itemCount: cs.length,
          onPageChanged: (i) => setState(() {
            _sel = cs[i].key;
            _lang = '';
          }),
          itemBuilder: (_, i) => _flag(i, cs),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
        child: Row(children: [
          Expanded(child: Text(_sel, style: ts(d, s: 16, b: true))),
          Text('${inCountry.length} ${context.t('radios')}', style: ts(d, s: 11, m: true)),
        ]),
      ),
      SizedBox(
        height: 40,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(18, 2, 10, 8), children: [
          for (final l in ['', ...langs.keys])
            Padding(
              padding: const EdgeInsets.only(right: 8, bottom: 6),
              child: Pill(l.isEmpty ? 'All' : l, on: _lang == l, onTap: () => setState(() => _lang = l)),
            ),
        ]),
      ),
      Expanded(child: stationsView(shown, 'list', pad: const EdgeInsets.fromLTRB(16, 4, 16, 16))),
    ]);
  }
}

// ------------------------------------------------------------ browse
class BrowsePage extends StatefulWidget {
  const BrowsePage({super.key});
  @override
  State<BrowsePage> createState() => _BrowsePageState();
}

class _BrowsePageState extends State<BrowsePage> {
  late final TextEditingController _ctl = TextEditingController(text: context.read<AppState>().query);

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final a = context.app;
    final open = context.select<AppState, bool>((s) => s.searchOpen);
    final cat = context.select<AppState, String>((s) => s.cat);
    final view = context.select<AppState, String>((s) => s.view);
    final items = context.select<AppState, List<Station>>((s) => s.filtered);
    final tabs = context.select<AppState, List<TabOpt>>((s) => s.cfg?.tabs ?? const []);
    final genre = context.select<AppState, String>((s) => s.genre);
    final language = context.select<AppState, String>((s) => s.language);
    final tag = context.select<AppState, String>((s) => s.tag);
    final tagline = context.select<AppState, String>((s) => s.cfg?.tagline ?? '');
    Widget tab(String label, String slug) => GestureDetector(
          onTap: () => a.setCat(slug),
          child: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(label, style: ts(d, s: 13, b: true, c: cat == slug ? d.ac : d.mu))),
              Container(height: 3, width: 24, decoration: BoxDecoration(color: cat == slug ? d.ac : Colors.transparent, borderRadius: BorderRadius.circular(3))),
            ]),
          ),
        );
    final active = [
      if (genre.isNotEmpty) ['genre', genre],
      if (language.isNotEmpty) ['language', language],
      if (tag.isNotEmpty) ['tag', '#$tag'],
    ];
    return Stack(fit: StackFit.expand, children: [
      Column(children: [
        topBar(context, title: context.t('browse'), sub: tagline, actions: [
          IBtn(open ? Icons.close : Icons.search, () {
            if (open) {
              _ctl.clear();
              a.setQuery('');
            }
            a.setSearchOpen(!open);
          }),
        ]),
        if (open)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(color: d.cd, borderRadius: BorderRadius.circular(99), border: Border.all(color: d.ac.withOpacity(.3))),
              child: Row(children: [
                Icon(Icons.search, size: 18, color: d.mu),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _ctl,
                    autofocus: true,
                    onChanged: a.setQuery,
                    style: ts(d, s: 13),
                    cursorColor: d.ac,
                    decoration: InputDecoration(border: InputBorder.none, isDense: true, hintText: context.t('search'), hintStyle: ts(d, s: 13, m: true)),
                  ),
                ),
              ]),
            ),
          ),
        SizedBox(
          height: 44,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            tab('All', ''),
            for (final t in tabs) tab(t.name, t.slug),
          ]),
        ),
        if (active.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Wrap(spacing: 6, runSpacing: 6, children: [
                for (final f in active)
                  Pill(f[1], on: true, onTap: () => a.clearFilter(f[0]), trailing: const Icon(Icons.close, size: 12, color: Colors.white)),
              ]),
            ),
          ),
        Expanded(
          child: items.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.search_off, size: 40, color: d.ac),
                  const SizedBox(height: 6),
                  Text('No radios found', style: ts(d, m: true)),
                ]))
              : stationsView(items, view),
        ),
      ]),
      Positioned(right: 18, bottom: 14, child: Gloss(size: 50, glow: 14, onTap: () => showFilters(context), child: const Icon(Icons.tune, color: Colors.white, size: 22))),
    ]);
  }
}

// ------------------------------------------------------------ filters sheet
void showFilters(BuildContext context) => showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _FiltersSheet(),
    );

class _FiltersSheet extends StatelessWidget {
  const _FiltersSheet();

  @override
  Widget build(BuildContext context) {
    final a = context.watch<AppState>();
    final d = a.ds;
    final w = MediaQuery.of(context).size.width;
    final genres = a.topBy((s) => s.genre.split(RegExp(r'[,;/|]')).map((e) => e.trim()));
    final langs = a.topBy((s) => [s.language], 10);
    final tags = a.topBy((s) => s.tags.split(RegExp(r'[,;|#]')).map((e) => e.trim().toLowerCase()), 12);
    final active = [
      if (a.genre.isNotEmpty) ['genre', a.genre],
      if (a.language.isNotEmpty) ['language', a.language],
      if (a.tag.isNotEmpty) ['tag', '#${a.tag}'],
    ];
    Widget tile(String v, IconData ic, String label) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Neo(
              sel: a.view == v,
              pad: const EdgeInsets.symmetric(vertical: 12),
              onTap: () => a.setView(v),
              child: Column(children: [Well(ic), const SizedBox(height: 4), Text(label, style: ts(d, s: 12))]),
            ),
          ),
        );
    return DraggableScrollableSheet(
      initialChildSize: .88,
      minChildSize: .5,
      maxChildSize: .95,
      expand: false,
      builder: (_, sc) => Container(
        decoration: BoxDecoration(color: d.bg, borderRadius: const BorderRadius.vertical(top: Radius.circular(26))),
        child: ListView(controller: sc, padding: const EdgeInsets.fromLTRB(16, 10, 16, 24), children: [
          Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: d.mu.withOpacity(.5), borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Text(a.t('filters'), style: ts(d, s: 18, b: true))),
            GestureDetector(
              onTap: a.clearFilters,
              child: Row(children: [Icon(Icons.refresh, size: 16, color: d.mu), const SizedBox(width: 4), Text(a.t('reset'), style: ts(d, s: 12, m: true))]),
            ),
          ]),
          const SizedBox(height: 8),
          if (active.isEmpty)
            Text('${a.filtered.length} ${a.t('radios')}', style: ts(d, s: 11, m: true))
          else
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final f in active) Pill(f[1], on: true, onTap: () => a.clearFilter(f[0]), trailing: const Icon(Icons.close, size: 12, color: Colors.white)),
            ]),
          Label(a.t('genre')),
          Wrap(spacing: 6, runSpacing: 14, children: [
            for (final g in genres)
              GestureDetector(
                onTap: () => a.toggleFilter('genre', g.key),
                child: SizedBox(
                  width: 64,
                  child: Column(children: [
                    a.genre == g.key
                        ? Gloss(size: 48, child: Icon(genreIcon(g.key), color: Colors.white, size: 21))
                        : Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: d.cd, boxShadow: [
                              BoxShadow(color: d.sh, offset: const Offset(4, 5), blurRadius: 10),
                              BoxShadow(color: d.hi, offset: const Offset(-3, -3), blurRadius: 8),
                            ]),
                            child: Icon(genreIcon(g.key), color: d.ac, size: 21)),
                    const SizedBox(height: 6),
                    Text(g.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 11, b: a.genre == g.key, m: a.genre != g.key)),
                  ]),
                ),
              ),
          ]),
          Label(a.t('lang')),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (final l in langs)
              SizedBox(
                width: (w - 32 - 10) / 2,
                child: Neo(
                  sel: a.language == l.key,
                  pad: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  onTap: () => a.toggleFilter('language', l.key),
                  child: Row(children: [
                    a.language == l.key
                        ? Gloss(size: 36, child: Text(_lt[l.key] ?? l.key[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)))
                        : Container(
                            width: 36,
                            height: 36,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: d.bg),
                            child: Text(_lt[l.key] ?? l.key[0], style: ts(d, s: 14, b: true, m: true))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(l.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 13, b: true)),
                        Text('${l.value} ${a.t('radios')}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(d, s: 10, m: true)),
                      ]),
                    ),
                  ]),
                ),
              ),
          ]),
          Label(a.t('tags')),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final t in tags)
              Pill('#${t.key}  ${t.value}', on: a.tag == t.key, onTap: () => a.toggleFilter('tag', t.key)),
          ]),
          Label(a.t('sortby')),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final s in const [['pop', 'Popular'], ['az', 'A–Z'], ['za', 'Z–A'], ['bh', 'Bitrate ↓'], ['bl', 'Bitrate ↑']])
              Pill(s[1], on: a.sort == s[0], onTap: () => a.setSort(s[0])),
          ]),
          const Label('View'),
          Row(children: [tile('list', Icons.view_list, 'List'), tile('grid', Icons.grid_view, 'Grid'), tile('classic', Icons.menu, 'Classic')]),
          const SizedBox(height: 18),
          Cta('${a.filtered.length} ${a.t('radios')}', onTap: () => Navigator.pop(context)),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------ favourites
class FavsPage extends StatelessWidget {
  const FavsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    context.select<AppState, int>((s) => s.favs.length);
    final favs = context.app.favs;
    final all = context.select<AppState, List<Station>>((s) => s.stations);
    final view = context.select<AppState, String>((s) => s.view);
    final items = all.where((s) => favs.contains(s.id)).toList();
    return Column(children: [
      topBar(context, title: context.t('fav'), actions: [
        Row(children: [const Icon(Icons.favorite, size: 16, color: _red), const SizedBox(width: 4), Text('${items.length}', style: ts(d, s: 12, m: true))]),
      ]),
      Expanded(
        child: items.isEmpty
            ? Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.favorite_border, size: 44, color: d.ac),
                  const SizedBox(height: 8),
                  Text('No favourites yet', style: ts(d, m: true)),
                  Text('Tap the heart on any station', style: ts(d, s: 11, m: true)),
                ]),
              )
            : stationsView(items, view),
      ),
    ]);
  }
}
