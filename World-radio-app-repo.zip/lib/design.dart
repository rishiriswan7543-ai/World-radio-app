import 'package:cached_network_image/cached_network_image.dart';
import 'package:circle_flags/circle_flags.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'api.dart';
import 'flags.dart';
import 'i18n.dart';
import 'state.dart';

/// Colour tokens, identical to the HTML mockup (dark and light).
@immutable
class Ds {
  final bool dark;
  final Color ac, a2, bg, cd, tx, mu, sh, hi;
  Ds(this.dark, this.ac, this.a2)
      : bg = dark ? const Color(0xFF0D0C1A) : const Color(0xFFE8E6F6),
        cd = dark ? const Color(0xFF1A1930) : const Color(0xFFF2F1FC),
        tx = dark ? const Color(0xFFF1F0FB) : const Color(0xFF1B1A2E),
        mu = dark ? const Color(0xFF9391B0) : const Color(0xFF68668A),
        sh = dark ? const Color(0x8C000000) : ac.withOpacity(.28),
        hi = dark ? const Color(0x0FFFFFFF) : const Color(0xFFFFFFFF);

  LinearGradient get grad => LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [ac, a2]);
}

extension Ctx on BuildContext {
  Ds get d => this.select<AppState, Ds>((s) => s.ds);
  String t(String k) => tr(this.select<AppState, String>((s) => s.lang), k);
  AppState get app => this.read<AppState>();
}

TextStyle ts(Ds d, {double s = 12, bool b = false, bool m = false, Color? c}) => TextStyle(
      fontSize: s,
      fontWeight: b ? FontWeight.w600 : FontWeight.w400,
      color: c ?? (m ? d.mu : d.tx),
      height: 1.35,
    );

/// Raised 3D card (two shadows, light-mode accent border).
class Neo extends StatelessWidget {
  final Widget child;
  final double r;
  final EdgeInsets pad;
  final VoidCallback? onTap;
  final bool sel;
  const Neo({super.key, required this.child, this.r = 16, this.pad = EdgeInsets.zero, this.onTap, this.sel = false});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: pad,
        decoration: BoxDecoration(
          color: d.cd,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(
              color: sel ? d.ac : (d.dark ? Colors.transparent : d.ac.withOpacity(.28)), width: sel ? 1.5 : 1),
          boxShadow: [
            BoxShadow(color: d.sh, offset: const Offset(6, 6), blurRadius: 14),
            BoxShadow(color: d.hi, offset: const Offset(-4, -4), blurRadius: 10),
          ],
        ),
        child: child,
      ),
    );
  }
}

Widget _shine() => IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-.4, -.56),
            radius: .9,
            colors: [Colors.white.withOpacity(.36), Colors.transparent],
            stops: const [0, .55],
          ),
        ),
      ),
    );

/// Round glossy accent button / badge.
class Gloss extends StatelessWidget {
  final double size;
  final Widget? child;
  final Gradient? grad;
  final VoidCallback? onTap;
  final double glow;
  const Gloss({super.key, this.size = 34, this.child, this.grad, this.onTap, this.glow = 0});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: grad ?? d.grad,
          boxShadow: [
            BoxShadow(color: d.sh, offset: const Offset(3, 4), blurRadius: 8),
            if (glow > 0) BoxShadow(color: d.ac.withOpacity(.5), blurRadius: glow),
          ],
        ),
        child: Stack(alignment: Alignment.center, children: [Positioned.fill(child: _shine()), if (child != null) child!]),
      ),
    );
  }
}

/// Soft inset round icon well (used for tiles and rows).
class Well extends StatelessWidget {
  final IconData icon;
  final double size;
  final Color? color;
  const Well(this.icon, {super.key, this.size = 42, this.color});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final c = color ?? d.ac;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color == null ? d.bg : c.withOpacity(.18),
        boxShadow: color == null ? [BoxShadow(color: d.sh.withOpacity(.25), blurRadius: 4, offset: const Offset(2, 2))] : null,
      ),
      child: Icon(icon, size: size * .48, color: c),
    );
  }
}

/// Round flag with ring and gloss. Falls back to initials for unknown countries.
class FlagC extends StatelessWidget {
  final String country;
  final double size;
  const FlagC(this.country, {super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    final iso = isoOf(country);
    final inner = size - 6;
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: d.cd,
        boxShadow: [BoxShadow(color: d.sh, offset: const Offset(3, 4), blurRadius: 8)],
      ),
      child: Stack(children: [
        Positioned.fill(
          child: iso == null
              ? Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: d.grad),
                  child: Text(country.isEmpty ? '?' : country.substring(0, country.length < 2 ? 1 : 2).toUpperCase(),
                      style: TextStyle(color: Colors.white, fontSize: inner * .34, fontWeight: FontWeight.w600)),
                )
              : CircleFlag(iso, size: inner),
        ),
        Positioned.fill(child: _shine()),
      ]),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool on;
  final VoidCallback onTap;
  final Widget? trailing;
  const Pill(this.text, {super.key, this.on = false, required this.onTap, this.trailing});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: on ? d.grad : null,
          color: on ? null : d.cd,
          borderRadius: BorderRadius.circular(99),
          border: (!d.dark && !on) ? Border.all(color: d.ac.withOpacity(.28)) : null,
          boxShadow: on
              ? null
              : [
                  BoxShadow(color: d.sh, offset: const Offset(3, 3), blurRadius: 7),
                  BoxShadow(color: d.hi, offset: const Offset(-2, -2), blurRadius: 6),
                ],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(text, style: ts(d, s: 11, c: on ? Colors.white : d.mu)),
          if (trailing != null) ...[const SizedBox(width: 4), trailing!],
        ]),
      ),
    );
  }
}

class Tog extends StatelessWidget {
  final bool v;
  final ValueChanged<bool> on;
  const Tog(this.v, this.on, {super.key});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: () => on(!v),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 40,
        height: 24,
        padding: const EdgeInsets.all(3),
        alignment: v ? Alignment.centerRight : Alignment.centerLeft,
        decoration: BoxDecoration(
          color: d.bg,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: v ? d.ac.withOpacity(.6) : d.mu.withOpacity(.3)),
        ),
        child: Container(width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: v ? d.ac : d.mu)),
      ),
    );
  }
}

class Label extends StatelessWidget {
  final String text;
  const Label(this.text, {super.key});
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.fromLTRB(2, 10, 0, 6), child: Text(text, style: ts(context.d, s: 11, m: true)));
}

/// Gradient art tile with the country flag; the station logo covers it when it loads.
class StationArt extends StatelessWidget {
  final Station st;
  const StationArt(this.st, {super.key});

  @override
  Widget build(BuildContext context) {
    final h = (st.id.hashCode.abs() % 360).toDouble();
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(fit: StackFit.expand, children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [HSLColor.fromAHSL(1, h, .55, .48).toColor(), HSLColor.fromAHSL(1, (h + 50) % 360, .55, .3).toColor()],
            ),
          ),
          child: Center(child: FlagC(st.country, size: 44)),
        ),
        if (st.logo.isNotEmpty)
          CachedNetworkImage(
            imageUrl: st.logo,
            fit: BoxFit.cover,
            memCacheWidth: 260,
            fadeInDuration: const Duration(milliseconds: 150),
            placeholder: (_, __) => const SizedBox.shrink(),
            errorWidget: (_, __, ___) => const SizedBox.shrink(),
          ),
      ]),
    );
  }
}

/// Round station logo (flag + logo overlay) for list rows and the mini player.
class StationDot extends StatelessWidget {
  final Station st;
  final double size;
  const StationDot(this.st, {super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: Stack(fit: StackFit.expand, children: [
          FlagC(st.country, size: size),
          if (st.logo.isNotEmpty)
            ClipOval(
              child: CachedNetworkImage(
                imageUrl: st.logo,
                fit: BoxFit.cover,
                memCacheWidth: 140,
                placeholder: (_, __) => const SizedBox.shrink(),
                errorWidget: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
        ]),
      );
}

IconData genreIcon(String g) {
  final x = g.toLowerCase();
  if (x.contains('news')) return Icons.newspaper;
  if (x.contains('talk') || x.contains('jazz')) return Icons.mic_none;
  if (x.contains('class') || x.contains('relig') || x.contains('devot')) return Icons.headphones;
  if (x.contains('retro') || x.contains('old') || x.contains('hits')) return Icons.access_time;
  if (x.contains('lo') && x.contains('fi')) return Icons.nightlight_round;
  if (x.contains('electro') || x.contains('dance') || x.contains('house')) return Icons.graphic_eq;
  if (x.contains('sport')) return Icons.sports_soccer;
  return Icons.music_note;
}

class Cta extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final bool gold;
  const Cta(this.text, {super.key, required this.onTap, this.gold = false});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: gold ? const LinearGradient(colors: [Color(0xFFFFD86B), Color(0xFFFF9A3C)]) : d.grad,
          borderRadius: BorderRadius.circular(99),
          boxShadow: [BoxShadow(color: d.sh, offset: const Offset(4, 6), blurRadius: 14)],
        ),
        child: Text(text,
            style: TextStyle(color: gold ? const Color(0xFF2B1A00) : Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

/// Header used by pushed screens: back arrow + title (+ optional right widget).
class Head extends StatelessWidget {
  final String title;
  final Widget? right;
  final bool back;
  const Head(this.title, {super.key, this.right, this.back = true});

  @override
  Widget build(BuildContext context) {
    final d = context.d;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
      child: Row(children: [
        if (back) IconButton(icon: Icon(Icons.chevron_left, color: d.tx, size: 28), onPressed: () => Navigator.maybePop(context)) else const SizedBox(width: 12),
        Expanded(child: Text(title, style: ts(d, s: 18, b: true))),
        if (right != null) right!,
      ]),
    );
  }
}
